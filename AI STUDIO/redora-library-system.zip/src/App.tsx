/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { LibraryProvider, useLibrary } from "./LibraryContext";
import { AnalyticsStats } from "./components/AnalyticsStats";
import { LoginPortal } from "./components/LoginPortal";
import { AdminDashboard } from "./components/AdminDashboard";
import { UserDashboardView } from "./components/UserDashboardView";
import { BookOpen, ShieldCheck, UserCheck, Sparkles, LogOut, Library, Palette, Database, Trash2, RotateCcw } from "lucide-react";

const THEMES = [
  { id: "redora", name: "Redora Velvet Crimson", color: "bg-rose-600 border-rose-300" },
  { id: "athena", name: "Athena Cobalt", color: "bg-indigo-600 border-indigo-300" },
  { id: "emerald", name: "Emerald Scholar", color: "bg-emerald-600 border-emerald-300" },
  { id: "purple", name: "Amethyst Grace", color: "bg-purple-600 border-purple-300" },
  { id: "charcoal", name: "Steel Graphite", color: "bg-slate-700 border-slate-400" },
  { id: "amber", name: "Warm Amber Wood", color: "bg-amber-500 border-amber-350" }
];

function LibraryAppContent() {
  const { currentUser, adminLoggedIn, logout, books, tables, users, currentTheme, setTheme, clearDatabase, loadMockData } = useLibrary();

  const activeReadersCount = users.filter(u => !u.isDeleted).length;

  return (
    <div className="min-h-screen flex flex-col">
      {/* Top Navbar */}
      <header className="bg-white border-b border-slate-100 sticky top-0 z-40 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 sm:h-16 flex flex-col sm:flex-row items-center justify-between py-2 sm:py-0 gap-2 sm:gap-4">
          <div className="flex items-center gap-3 self-start sm:self-auto">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-xs md:shadow-indigo-100 transition-colors duration-300">
              <BookOpen className="w-5.5 h-5.5" />
            </div>
            <div>
              <span className="font-display font-extrabold text-slate-900 tracking-tight text-base sm:text-lg block">Redora Library</span>
              <span className="text-[10px] text-slate-400 font-mono tracking-widest uppercase font-bold block leading-none">Management System</span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 sm:gap-4 justify-end w-full sm:w-auto self-end sm:self-auto">
            {/* Interactive Theme Palette Selector */}
            <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-100 rounded-xl px-2.5 py-1.5" title="Custom App Dashboard Theme">
              <Palette className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <div className="flex items-center gap-1">
                {THEMES.map(th => {
                  const isActive = currentTheme === th.id;
                  return (
                    <button
                      key={th.id}
                      onClick={() => setTheme(th.id)}
                      className={`w-4 h-4 rounded-full ${th.color} cursor-pointer border hover:scale-115 active:scale-95 transition-all duration-150 relative ${
                        isActive 
                          ? "ring-2 ring-indigo-500 ring-offset-1 z-10 scale-110" 
                          : "opacity-75 hover:opacity-100"
                      }`}
                      title={`${th.name} Theme`}
                    />
                  );
                })}
              </div>
            </div>

            {/* Active login roles statuses */}
            <div className="flex items-center gap-2">
              {adminLoggedIn && (
                <div className="flex items-center gap-2 bg-slate-50 border border-slate-100 rounded-xl px-3 py-1.5 font-mono text-xs text-slate-700">
                  <ShieldCheck className="w-4 h-4 text-amber-500 fill-amber-100" />
                  <span className="hidden md:inline">Operating is:</span>
                  <span className="font-bold">Librarian Admin</span>
                </div>
              )}

              {currentUser && (
                <div className="flex items-center gap-2 bg-slate-50 border border-slate-100 rounded-xl px-3 py-1.5 text-xs text-slate-700 font-mono">
                  <UserCheck className="w-4 h-4 text-indigo-500" />
                  <span className="hidden md:inline">Reader:</span>
                  <span className="font-bold truncate max-w-[80px] sm:max-w-[120px]">{currentUser.name}</span>
                </div>
              )}

              {(adminLoggedIn || currentUser) && (
                <button
                  onClick={logout}
                  className="bg-slate-50 hover:bg-slate-100 text-slate-600 border border-slate-150 p-2 rounded-xl transition duration-150 shrink-0 cursor-pointer"
                  title="Sign out of current desk session"
                >
                  <LogOut className="w-4.5 h-4.5" />
                </button>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Container Work space */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        
        {/* Active Database Slate Controller panel */}
        <section className="bg-slate-50/50 rounded-2xl border border-slate-100 p-4 flex flex-col md:flex-row items-center justify-between gap-4 animate-fade-in shadow-xs">
          <div className="flex items-center gap-3 self-start md:self-auto">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/10 flex items-center justify-center text-indigo-400">
              <Database className="w-5 h-5 text-indigo-500" />
            </div>
            <div>
              <div className="flex items-center gap-2 leading-none">
                <span className="font-display font-bold text-slate-900 text-sm">Active Database Engine</span>
                {books.length === 0 && tables.length === 0 && activeReadersCount === 0 ? (
                  <span className="bg-emerald-500/15 text-emerald-400 text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full border border-emerald-500/10 font-mono">
                    Clean Slate Active
                  </span>
                ) : (
                  <span className="bg-indigo-500/15 text-indigo-400 text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full border border-indigo-500/10 font-mono">
                    Populated
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400 mt-1.5 font-mono">
                Current Records: <b className="text-slate-800">{books.length}</b> books • <b className="text-slate-800">{tables.length}</b> rooms/tables • <b className="text-slate-800">{activeReadersCount}</b> registered readers
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 w-full md:w-auto justify-end">
            <button
              onClick={() => {
                if (confirm("Wipe all locally stored books, tables, reservations, and reader users? This lets you enter 100% of your own data.")) {
                  clearDatabase();
                }
              }}
              className="flex-1 md:flex-none flex items-center justify-center gap-2 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/25 px-3 py-1.5 rounded-xl text-xs font-bold transition duration-150 cursor-pointer"
              title="Wipe database to clean slate"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Wipe DB (Fresh Slate)</span>
            </button>

            <button
              onClick={() => {
                if (confirm("Restore academic demo catalogs, rooms, and preloaded sample users?")) {
                  loadMockData();
                }
              }}
              className="flex-1 md:flex-none flex items-center justify-center gap-2 bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-400 border border-indigo-500/25 px-3 py-1.5 rounded-xl text-xs font-bold transition duration-150 cursor-pointer"
              title="Reset configuration defaults & seeds"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Load Seed Samples</span>
            </button>
          </div>
        </section>

        {/* Informative Help Callout when 100% empty */}
        {books.length === 0 && tables.length === 0 && activeReadersCount === 0 && (
          <section className="bg-gradient-to-r from-emerald-500/10 to-indigo-500/10 border border-emerald-500/15 rounded-2xl p-5 text-slate-800 animate-slide-up">
            <h4 className="font-display font-extrabold text-sm text-slate-900 tracking-tight flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-400 animate-pulse" />
              Database is 100% Empty & Personal Customizable!
            </h4>
            <p className="text-xs text-slate-500 mt-2 leading-relaxed">
              You are the sole author of this Redora Library system. Follow these simple steps to enter your own records:
            </p>
            <ol className="list-decimal list-inside text-xs text-slate-500 space-y-1.5 mt-2.5 font-mono">
              <li>Click <b className="text-slate-800">Librarian Admin Login</b> inside the workspace and type the Master Key: <code className="bg-slate-100 px-1 py-0.5 rounded text-rose-500 font-bold font-mono">123</code>.</li>
              <li>Manually add custom computer racks or quiet study rooms (e.g. "Main Lab Area Desk 5").</li>
              <li>Catalog your library book collection with custom titles, authors, and download access.</li>
              <li>Log out, or click <b className="text-slate-800">Reader Registration</b> to register personalized reader accounts with custom initial credit limits, ready to borrow or book space!</li>
            </ol>
          </section>
        )}

        {/* Popular Engagement Stats bar (accessible to all viewers instantly) */}
        <section id="analytics-section" className="animate-fade-in">
          <AnalyticsStats books={books} />
        </section>

        {/* Dynamic Panels according to log in roles */}
        <section id="workspace-section" className="transition-all duration-300">
          {adminLoggedIn ? (
            <AdminDashboard />
          ) : currentUser ? (
            <UserDashboardView />
          ) : (
            <LoginPortal />
          )}
        </section>
      </main>

      {/* Global elegant footer */}
      <footer className="bg-white border-t border-slate-100 text-center py-6 text-xs text-slate-400 font-mono">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row justify-between items-center gap-3">
          <span>© 2026 Academic Redora Library Desk System • All Rights Reserved</span>
          <span className="text-[10px] bg-slate-50 px-2 py-1 rounded border border-slate-100 flex items-center gap-1">
            <Library className="w-3.5 h-3.5 text-indigo-500" />
            Vite SPA • Local Persisted Engine
          </span>
        </div>
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <LibraryProvider>
      <LibraryAppContent />
    </LibraryProvider>
  );
}
