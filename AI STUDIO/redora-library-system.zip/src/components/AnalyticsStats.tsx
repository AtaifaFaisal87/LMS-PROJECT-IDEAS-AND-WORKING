import React, { useState } from "react";
import { Book } from "../types";
import { BarChart2, BookOpen, Download, RefreshCw, Award, ArrowUpRight, TrendingUp } from "lucide-react";

interface AnalyticsStatsProps {
  books: Book[];
}

type MetricsFilter = "ENGAGEMENT" | "READ_ONSITE" | "DOWNLOADS" | "BORROWS";

export const AnalyticsStats: React.FC<AnalyticsStatsProps> = ({ books }) => {
  const [activeFilter, setActiveFilter] = useState<MetricsFilter>("ENGAGEMENT");

  // Calculate Engagement Rating for each book: On-site + Downloads * 1.5 + Borrowed * 2.0 (weighted activity score)
  const getScore = (book: Book, type: MetricsFilter): number => {
    switch (type) {
      case "READ_ONSITE":
        return book.read_onsite_count;
      case "DOWNLOADS":
        return book.download_count;
      case "BORROWS":
        return book.times_borrowed;
      case "ENGAGEMENT":
      default:
        return book.read_onsite_count + book.download_count * 1.25 + book.times_borrowed * 1.5;
    }
  };

  const getLabel = (type: MetricsFilter): string => {
    switch (type) {
      case "READ_ONSITE":
        return "Reads On-Site";
      case "DOWNLOADS":
        return "Downloads";
      case "BORROWS":
        return "Times Borrowed";
      case "ENGAGEMENT":
      default:
        return "Total Engagement Index";
    }
  };

  // Sort books according to current filter
  const sortedBooks = [...books].sort((a, b) => getScore(b, activeFilter) - getScore(a, activeFilter));
  const maxScore = sortedBooks.length > 0 ? getScore(sortedBooks[0], activeFilter) : 1;

  // Global aggregate summaries
  const totalOnsite = books.reduce((sum, b) => sum + b.read_onsite_count, 0);
  const totalDownloads = books.reduce((sum, b) => sum + b.download_count, 0);
  const totalBorrows = books.reduce((sum, b) => sum + b.times_borrowed, 0);
  const totalEngagement = totalOnsite + totalDownloads * 1.25 + totalBorrows * 1.5;

  const topBook = books.reduce((top, current) => {
    const topScore = top ? getScore(top, "ENGAGEMENT") : -1;
    const currentScore = getScore(current, "ENGAGEMENT");
    return currentScore > topScore ? current : top;
  }, books[0] || null);

  return (
    <div id="analytics-root" className="bg-white rounded-2xl border border-slate-100 p-6 md:p-8 shadow-sm">
      <div className="flex flex-col lg:flex-row justify-between lg:items-center gap-4 mb-8">
        <div>
          <span className="text-xs font-semibold tracking-wider text-slate-400 uppercase font-mono">Real-Time Metrics</span>
          <h2 className="text-2xl font-bold tracking-tight text-slate-800 flex items-center gap-2 mt-1">
            <BarChart2 className="w-5 h-5 text-indigo-500" />
            Library Engagement Analytics
          </h2>
          <p className="text-slate-500 text-sm mt-0.5">Statistical insights tracking which book catalog is utilized the most.</p>
        </div>

        {/* Filter Controls */}
        <div className="flex flex-wrap gap-1.5 bg-slate-50 p-1 rounded-xl self-start border border-slate-100">
          {(["ENGAGEMENT", "READ_ONSITE", "DOWNLOADS", "BORROWS"] as MetricsFilter[]).map((filter) => (
            <button
              key={filter}
              onClick={() => setActiveFilter(filter)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all duration-200 cursor-pointer ${
                activeFilter === filter
                  ? "bg-white text-slate-900 shadow-sm border border-slate-100"
                  : "text-slate-500 hover:text-slate-900 hover:bg-slate-100/50"
              }`}
            >
              {filter === "ENGAGEMENT" && "All Activity"}
              {filter === "READ_ONSITE" && "Reads On-Site"}
              {filter === "DOWNLOADS" && "Downloads"}
              {filter === "BORROWS" && "Borrows"}
            </button>
          ))}
        </div>
      </div>

      {/* Main KPI cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <div className="bg-slate-50 border border-slate-100/80 rounded-xl p-4 flex items-center gap-4">
          <div className="w-10 h-10 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div>
            <span className="text-slate-400 text-xs font-mono block">Aggregate Score</span>
            <span className="text-xl font-bold text-slate-800">{Math.round(totalEngagement).toLocaleString()}</span>
          </div>
        </div>

        <div className="bg-slate-50 border border-slate-100/80 rounded-xl p-4 flex items-center gap-4">
          <div className="w-10 h-10 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <span className="text-slate-400 text-xs font-mono block">On-Site Reads</span>
            <span className="text-xl font-bold text-slate-800">{totalOnsite.toLocaleString()}</span>
          </div>
        </div>

        <div className="bg-slate-50 border border-slate-100/80 rounded-xl p-4 flex items-center gap-4">
          <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
            <Download className="w-5 h-5" />
          </div>
          <div>
            <span className="text-slate-400 text-xs font-mono block">E-Downloads</span>
            <span className="text-xl font-bold text-slate-800">{totalDownloads.toLocaleString()}</span>
          </div>
        </div>

        <div className="bg-slate-50 border border-slate-100/80 rounded-xl p-4 flex items-center gap-4">
          <div className="w-10 h-10 rounded-lg bg-violet-50 text-violet-600 flex items-center justify-center shrink-0">
            <RefreshCw className="w-5 h-5" />
          </div>
          <div>
            <span className="text-slate-400 text-xs font-mono block">Total Borrowed</span>
            <span className="text-xl font-bold text-slate-800">{totalBorrows.toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* Grid: Bar Columns Analysis Left, Special Spotlight Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Statistics Bar Column List */}
        <div className="lg:col-span-8 flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-semibold text-slate-700 uppercase tracking-wide font-mono mb-4 flex items-center gap-1.5">
              <span>Catalog Leaderboard</span>
              <span className="text-xs text-indigo-500 lowercase bg-indigo-50 px-2 py-0.5 rounded-full">sorted by {getLabel(activeFilter)}</span>
            </h3>
            
            <div className="space-y-4">
              {sortedBooks.slice(0, 5).map((book, index) => {
                const score = getScore(book, activeFilter);
                const percent = maxScore > 0 ? (score / maxScore) * 100 : 0;
                
                return (
                  <div key={book.id} className="relative group p-1.5 rounded-lg hover:bg-slate-50/50 transition duration-150">
                    <div className="flex items-center justify-between text-sm mb-1">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <span className="text-xs font-mono font-bold text-slate-400 w-4 block">
                          #{index + 1}
                        </span>
                        <div className="truncate">
                          <span className="font-medium text-slate-700 block truncate">{book.title}</span>
                          <span className="text-slate-400 text-xs truncate block">{book.author} • {book.category}</span>
                        </div>
                      </div>
                      <span className="text-xs font-semibold text-indigo-600 bg-indigo-50 px-2 py-1 rounded-md font-mono shrink-0">
                        {Math.round(score).toLocaleString()}
                      </span>
                    </div>

                    {/* Progress Bar Container */}
                    <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden mt-1.5">
                      <div
                        className={`h-full rounded-full transition-all duration-1000 ease-out ${
                          index === 0 ? "bg-gradient-to-r from-indigo-500 to-indigo-600" :
                          index === 1 ? "bg-gradient-to-r from-emerald-400 to-emerald-500" :
                          index === 2 ? "bg-gradient-to-r from-blue-400 to-blue-500" :
                          "bg-slate-400"
                        }`}
                        style={{ width: `${percent}%` }}
                      />
                    </div>
                  </div>
                );
              })}
              
              {sortedBooks.length === 0 && (
                <div className="text-center py-8 border-2 border-dashed border-slate-100 rounded-xl text-slate-400 text-sm">
                  No books cataloged. Statistics will show up here.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Book Spotlight Callout panel */}
        {topBook && (
          <div className="lg:col-span-4 bg-gradient-to-b from-indigo-900 to-indigo-950 text-white rounded-2xl p-6 shadow-md border border-indigo-950 flex flex-col justify-between relative overflow-hidden">
            {/* Background design glow */}
            <div className="absolute top-0 right-0 w-36 h-36 bg-indigo-500/10 rounded-full blur-2xl transform translate-x-12 -translate-y-12 shrink-0 pointer-events-none" />
            
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="bg-indigo-500/15 text-indigo-200 border border-indigo-400/20 text-[10px] font-bold tracking-wider uppercase font-mono px-2.5 py-1 rounded-full flex items-center gap-1">
                  <Award className="w-3.5 h-3.5 text-yellow-300 fill-yellow-300" />
                  Popularity Crown
                </span>
                <span className="text-indigo-400 text-[10px] font-mono">Top Engaged Book</span>
              </div>

              <h4 className="text-xl font-bold leading-tight tracking-tight mb-1 text-white truncate-2-lines">
                {topBook.title}
              </h4>
              <p className="text-indigo-200/80 text-xs mb-6">by {topBook.author}</p>

              <div className="space-y-3.5 text-xs border-t border-indigo-400/10 pt-4">
                <div className="flex justify-between items-center text-indigo-200/70">
                  <span>Reads On-Site</span>
                  <span className="font-mono font-bold text-white">{topBook.read_onsite_count}</span>
                </div>
                <div className="flex justify-between items-center text-indigo-200/70">
                  <span>PDF Downloads</span>
                  <span className="font-mono font-bold text-white">{topBook.download_count}</span>
                </div>
                <div className="flex justify-between items-center text-indigo-200/70">
                  <span>Times Borrowed</span>
                  <span className="font-mono font-bold text-white">{topBook.times_borrowed}</span>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-indigo-400/10 flex items-center justify-between text-xs text-indigo-300">
              <span className="flex items-center gap-1 text-[11px] font-mono">
                Overall Index: <b className="text-white font-mono">{Math.round(getScore(topBook, "ENGAGEMENT"))}</b>
              </span>
              <span className="flex items-center gap-0.5 text-amber-300 text-[11px]">
                Leader
                <ArrowUpRight className="w-3.5 h-3.5" />
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
