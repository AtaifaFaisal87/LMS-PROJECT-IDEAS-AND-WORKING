import React, { useState } from "react";
import { useLibrary } from "../LibraryContext";
import { UserType } from "../types";
import { KeyRound, ShieldAlert, UserPlus, LogIn, Mail, Lock, Sparkles, UserCheck, Smartphone, BookOpen } from "lucide-react";

export const LoginPortal: React.FC = () => {
  const { loginAsUser, loginAsAdmin, registerUser } = useLibrary();

  const [activeTab, setActiveTab] = useState<"USER_LOGIN" | "ADMIN_LOGIN" | "REGISTER">("USER_LOGIN");
  
  // Login fields
  const [loginUsername, setLoginUsername] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  
  // Admin fields
  const [adminPassword, setAdminPassword] = useState("");

  // Registration fields
  const [regName, setRegName] = useState("");
  const [regCnic, setRegCnic] = useState("");
  const [regEmail, setRegEmail] = useState("");
  const [regPhone, setRegPhone] = useState("");
  const [regUsername, setRegUsername] = useState("");
  const [regPassword, setRegPassword] = useState("");
  const [regType, setRegType] = useState<UserType>("STUDENT");
  const [regBalance, setRegBalance] = useState<string>("500");

  // Type specific registration fields
  const [seatno, setSeatno] = useState("");
  const [major, setMajor] = useState("");
  const [department, setDepartment] = useState("");
  const [designation, setDesignation] = useState("");
  const [purpose, setPurpose] = useState("");

  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const clearNotifications = () => {
    setErrorMsg(null);
    setSuccessMsg(null);
  };

  const handleUserLogin = (e: React.FormEvent) => {
    e.preventDefault();
    clearNotifications();
    if (!loginUsername || !loginPassword) {
      setErrorMsg("Please fill in both fields.");
      return;
    }
    const res = loginAsUser(loginUsername, loginPassword);
    if (!res.success) {
      setErrorMsg(res.message);
    } else {
      setSuccessMsg(res.message);
    }
  };

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    clearNotifications();
    if (!adminPassword) {
      setErrorMsg("Please enter password.");
      return;
    }
    const res = loginAsAdmin(adminPassword);
    if (!res.success) {
      setErrorMsg(res.message);
    } else {
      setSuccessMsg(res.message);
    }
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    clearNotifications();

    // Verify CNIC syntax: xxxxx-xxxxxxx-x
    const cnicRegex = /^\d{5}-\d{7}-\d{1}$/;
    if (!cnicRegex.test(regCnic)) {
      setErrorMsg("CNIC format must be xxxxx-xxxxxxx-x");
      return;
    }

    // Verify format: 03xxxxxxxxx
    const phoneRegex = /^03\d{9}$/;
    if (!phoneRegex.test(regPhone)) {
      setErrorMsg("Phone number must start with '03' and have exactly 11 digits (e.g., 03001234567)");
      return;
    }

    // Email pattern check
    if (!regEmail.includes("@") || !regEmail.includes(".")) {
      setErrorMsg("Please enter a valid email address containing '@' and '.'");
      return;
    }

    if (regPassword.length < 6) {
      setErrorMsg("Password is too short! Minimum 6 characters required.");
      return;
    }

    const typeFields: any = {};
    if (regType === "STUDENT") {
      if (!seatno || !major) {
        setErrorMsg("Please fill in Student seat number and major.");
        return;
      }
      typeFields.seatno = seatno;
      typeFields.major = major;
    } else if (regType === "FACULTY") {
      if (!department || !designation) {
        setErrorMsg("Please fill in Department and Academic Designation.");
        return;
      }
      typeFields.department = department;
      typeFields.designation = designation;
    } else if (regType === "GUEST") {
      if (!purpose) {
        setErrorMsg("Please clarify the purpose for guest card issue.");
        return;
      }
      typeFields.purpose = purpose;
    }

    const initialBalNum = parseFloat(regBalance) || 0;
    if (initialBalNum < 0) {
      setErrorMsg("Initial balance cannot be negative!");
      return;
    }

    const res = registerUser({
      name: regName,
      cnic: regCnic,
      email: regEmail,
      phone: regPhone,
      username: regUsername,
      password: regPassword,
      type: regType,
      balance: initialBalNum,
      ...typeFields
    });

    if (!res.success) {
      setErrorMsg(res.message);
    } else {
      setSuccessMsg(res.message + " Switching to login.");
      // Clear registration state
      setRegName("");
      setRegCnic("");
      setRegEmail("");
      setRegPhone("");
      setRegUsername("");
      setRegPassword("");
      setSeatno("");
      setMajor("");
      setDepartment("");
      setDesignation("");
      setPurpose("");
      
      // Auto switch tabs
      setTimeout(() => {
        setActiveTab("USER_LOGIN");
        clearNotifications();
      }, 1500);
    }
  };

  return (
    <div id="login-container" className="max-w-xl mx-auto bg-white rounded-2xl border border-slate-100 p-8 shadow-sm">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center p-3 rounded-xl bg-indigo-50 text-indigo-600 mb-3">
          <BookOpen className="w-8 h-8" />
        </div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-800">Redora Academic Library</h1>
        <p className="text-slate-500 text-sm mt-1">Redora Smart Library Desk & Interactive Portal</p>
      </div>

      {/* Tabs list */}
      <div className="flex border-b border-slate-100 mb-6 font-medium">
        <button
          onClick={() => { setActiveTab("USER_LOGIN"); clearNotifications(); }}
          className={`flex-1 pb-3 text-sm transition-all relative cursor-pointer ${
            activeTab === "USER_LOGIN" ? "text-indigo-600 font-semibold" : "text-slate-400 hover:text-slate-600"
          }`}
        >
          Reader Log In
          {activeTab === "USER_LOGIN" && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-600" />}
        </button>
        <button
          onClick={() => { setActiveTab("REGISTER"); clearNotifications(); }}
          className={`flex-1 pb-3 text-sm transition-all relative cursor-pointer ${
            activeTab === "REGISTER" ? "text-indigo-600 font-semibold" : "text-slate-400 hover:text-slate-600"
          }`}
        >
          Sign Up Card
          {activeTab === "REGISTER" && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-600" />}
        </button>
        <button
          onClick={() => { setActiveTab("ADMIN_LOGIN"); clearNotifications(); }}
          className={`flex-1 pb-3 text-sm transition-all relative cursor-pointer ${
            activeTab === "ADMIN_LOGIN" ? "text-indigo-600 font-semibold" : "text-slate-400 hover:text-slate-600"
          }`}
        >
          Librarian Gate
          {activeTab === "ADMIN_LOGIN" && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-600" />}
        </button>
      </div>

      {/* Message banners */}
      {errorMsg && (
        <div className="mb-6 p-4 rounded-xl bg-rose-50 border border-rose-100/50 text-rose-600 text-xs font-semibold flex items-center gap-3">
          <ShieldAlert className="w-4 h-4 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}
      {successMsg && (
        <div className="mb-6 p-4 rounded-xl bg-emerald-50 border border-emerald-100/50 text-emerald-700 text-xs font-semibold flex items-center gap-3">
          <Sparkles className="w-4 h-4 shrink-0 text-emerald-500" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* FORMS */}
      {activeTab === "USER_LOGIN" && (
        <form onSubmit={handleUserLogin} className="space-y-4">
          <div>
            <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 font-mono mb-1.5 block">Username</label>
            <div className="relative">
              <Mail className="absolute left-3.5 top-3.5 w-4.5 h-4.5 text-slate-400" />
              <input
                type="text"
                value={loginUsername}
                onChange={(e) => setLoginUsername(e.target.value)}
                placeholder="e.g. alex"
                className="w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-xl text-slate-700 text-sm focus:outline-none focus:border-indigo-500/80 focus:bg-white transition-all font-medium"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 font-mono mb-1.5 block">Password</label>
            <div className="relative">
              <Lock className="absolute left-3.5 top-3.5 w-4.5 h-4.5 text-slate-400" />
              <input
                type="password"
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
                placeholder="••••••"
                className="w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-xl text-slate-700 text-sm focus:outline-none focus:border-indigo-500/80 focus:bg-white transition-all font-medium"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3 px-4 rounded-xl font-semibold transition duration-150 shadow-sm shadow-indigo-100/30 flex items-center justify-center gap-2 cursor-pointer mt-6"
          >
            <LogIn className="w-4 h-4" />
            Check-In Desk
          </button>

          <div className="mt-6 border-t border-slate-50 pt-4 text-center">
            <span className="text-[11px] text-slate-400 uppercase tracking-widest font-bold block mb-2 font-mono">Demo Accounts</span>
            <div className="inline-flex gap-4 text-xs font-mono text-slate-500 bg-slate-50/50 rounded-lg p-2.5 border border-slate-100/30">
              <div>User: <span className="font-semibold text-slate-800">alex</span> | <span className="font-semibold text-slate-800">password</span></div>
              <div>Faculty: <span className="font-semibold text-slate-800">eleanor</span> | <span className="font-semibold text-slate-800">password</span></div>
            </div>
          </div>
        </form>
      )}

      {activeTab === "ADMIN_LOGIN" && (
        <form onSubmit={handleAdminLogin} className="space-y-4">
          <div className="p-3 bg-amber-50 text-amber-700 text-[11px] leading-relaxed rounded-xl border border-amber-100/50 mb-2">
            Librarian administrator system access. Restricted to desk operators. Standard pin credentials configured.
          </div>

          <div>
            <div className="flex justify-between mb-1.5">
              <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 font-mono block">Security Passphrase</label>
              <span className="text-[10px] text-slate-400 bg-slate-100/50 font-mono px-1.5 py-0.5 rounded">Demo: 123</span>
            </div>
            <div className="relative">
              <Lock className="absolute left-3.5 top-3.5 w-4.5 h-4.5 text-slate-400" />
              <input
                type="password"
                value={adminPassword}
                onChange={(e) => setAdminPassword(e.target.value)}
                placeholder="Librarian Terminal Code"
                className="w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-xl text-slate-700 text-sm focus:outline-none focus:border-indigo-500/80 focus:bg-white transition-all font-medium"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-slate-850 hover:bg-slate-900 text-white py-3 px-4 rounded-xl font-semibold transition duration-150 flex items-center justify-center gap-2 cursor-pointer mt-6"
          >
            <KeyRound className="w-4 h-4 text-indigo-400" />
            Operator Access
          </button>
        </form>
      )}

      {activeTab === "REGISTER" && (
        <form onSubmit={handleRegister} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 font-mono mb-1.5 block">Full Name</label>
              <input
                type="text"
                required
                value={regName}
                onChange={(e) => setRegName(e.target.value)}
                placeholder="e.g. Alex Mercer"
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-100 rounded-xl text-slate-700 text-sm focus:outline-none"
              />
            </div>

            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 font-mono mb-1.5 block">CNIC</label>
              <input
                type="text"
                required
                value={regCnic}
                onChange={(e) => setRegCnic(e.target.value)}
                placeholder="e.g. 42101-1234567-1"
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-100 rounded-xl text-slate-700 text-sm focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 font-mono mb-1.5 block">Email Address</label>
              <input
                type="email"
                required
                value={regEmail}
                onChange={(e) => setRegEmail(e.target.value)}
                placeholder="alex@gmail.com"
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-100 rounded-xl text-slate-700 text-sm focus:outline-none"
              />
            </div>

            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 font-mono mb-1.5 block">Phone Number</label>
              <input
                type="text"
                required
                value={regPhone}
                onChange={(e) => setRegPhone(e.target.value)}
                placeholder="e.g. 03001234567"
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-100 rounded-xl text-slate-700 text-sm focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 font-mono mb-1.5 block">Create Username</label>
              <input
                type="text"
                required
                value={regUsername}
                onChange={(e) => setRegUsername(e.target.value)}
                placeholder="Username"
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-100 rounded-xl text-slate-700 text-sm focus:outline-none"
              />
            </div>

            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 font-mono mb-1.5 block">Create Password</label>
              <input
                type="password"
                required
                value={regPassword}
                onChange={(e) => setRegPassword(e.target.value)}
                placeholder="Min 6 characters"
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-100 rounded-xl text-slate-700 text-sm focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 font-mono mb-1.5 block">Card Member Type</label>
              <select
                value={regType}
                onChange={(e) => setRegType(e.target.value as UserType)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-100 rounded-xl text-slate-700 text-sm focus:outline-none"
              >
                <option value="STUDENT">Student Card (Limit 3, Fine Rs.10/min)</option>
                <option value="FACULTY">Faculty Card (Limit 5, Fine Rs.15/min)</option>
                <option value="GUEST">Guest Desk Card (Limit 1, Fine Rs.20/min)</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 font-mono mb-1.5 block">Initial Deposit (PKR)</label>
              <input
                type="number"
                min="0"
                value={regBalance}
                onChange={(e) => setRegBalance(e.target.value)}
                placeholder="Rs."
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-100 rounded-xl text-slate-700 text-sm focus:outline-none"
              />
            </div>
          </div>

          {/* TYPE-SPECIFIC BONUS INPUT FIELDS */}
          <div className="border-t border-slate-50 pt-4 mt-2">
            {regType === "STUDENT" && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 font-mono mb-1.5 block">University Seat Number</label>
                  <input
                    type="text"
                    required
                    value={seatno}
                    onChange={(e) => setSeatno(e.target.value)}
                    placeholder="e.g. CS-409"
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-100 rounded-xl text-slate-700 text-sm focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 font-mono mb-1.5 block">Academic Major Department</label>
                  <input
                    type="text"
                    required
                    value={major}
                    onChange={(e) => setMajor(e.target.value)}
                    placeholder="e.g. Software Engineering"
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-100 rounded-xl text-slate-700 text-sm focus:outline-none"
                  />
                </div>
              </div>
            )}

            {regType === "FACULTY" && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 font-mono mb-1.5 block">Academic Department</label>
                  <input
                    type="text"
                    required
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    placeholder="e.g. Applied Physics"
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-100 rounded-xl text-slate-700 text-sm focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 font-mono mb-1.5 block">Designation Title</label>
                  <input
                    type="text"
                    required
                    value={designation}
                    onChange={(e) => setDesignation(e.target.value)}
                    placeholder="e.g. Assistant Professor"
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-100 rounded-xl text-slate-700 text-sm focus:outline-none"
                  />
                </div>
              </div>
            )}

            {regType === "GUEST" && (
              <div>
                <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 font-mono mb-1.5 block">Purpose of Reference Request</label>
                <input
                  type="text"
                  required
                  value={purpose}
                  onChange={(e) => setPurpose(e.target.value)}
                  placeholder="e.g. Independent Research Consultation"
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-100 rounded-xl text-slate-700 text-sm focus:outline-none"
                />
              </div>
            )}
          </div>

          <button
            type="submit"
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-3 px-4 rounded-xl font-semibold transition duration-150 flex items-center justify-center gap-2 cursor-pointer mt-6"
          >
            <UserPlus className="w-4 h-4" />
            Issue Library Access Card
          </button>
        </form>
      )}
    </div>
  );
};
