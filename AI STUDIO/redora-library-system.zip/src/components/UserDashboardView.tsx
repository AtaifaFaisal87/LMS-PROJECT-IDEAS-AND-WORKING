import React, { useState } from "react";
import { useLibrary } from "../LibraryContext";
import { Book, Table, BookReservation } from "../types";
import { 
  BookOpen, Download, Calendar, Sparkles, User, KeyRound, Smartphone, Search, Check, AlertTriangle,
  CreditCard, Wallet, Layers, Eye, Ban, XCircle, ArrowUpRight, ChevronRight, Award, Flame, LogOut, Clock
} from "lucide-react";

export const UserDashboardView: React.FC = () => {
  const {
    currentUser, books, tables, transactions, fines, reservations, logout,
    getEffectiveBorrowLimit, hasOverdueBooks, getOverdueBooksCount,
    updateUserProfile, addFunds, activateMembership, cancelMembership,
    borrowBook, returnBook, readOnSite, downloadBook,
    reserveTableManual, reserveTableAuto, reserveBookOnsite, cancelReservation
  } = useLibrary();

  const [activeTab, setActiveTab] = useState<"SEARCH" | "MY_BORROWS" | "RESERVATIONS" | "MEMBERSHIP" | "UPDATE_PROFILE">("SEARCH");

  // Lookup helper
  const bMap = React.useMemo(() => new Map(books.map(b => [b.id, b])), [books]);
  const tableMap = React.useMemo(() => new Map(tables.map(t => [t.id, t])), [tables]);

  // Notifications
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const displayFeedback = (res: { success: boolean; message: string }) => {
    if (res.success) {
      setSuccessMsg(res.message);
      setErrorMsg(null);
      setTimeout(() => setSuccessMsg(null), 5000);
    } else {
      setErrorMsg(res.message);
      setSuccessMsg(null);
      setTimeout(() => setErrorMsg(null), 5000);
    }
  };

  // --- CATALOG & SEARCH STATE ---
  const [searchVal, setSearchVal] = useState("");
  const [catFilter, setCatFilter] = useState("ALL");
  const [selectedBook, setSelectedBook] = useState<Book | null>(null);

  // --- ACTIONS STATE ---
  const [borrowMinutes, setBorrowMinutes] = useState<number>(30); // default 30 mins
  const [downloadProgress, setDownloadProgress] = useState<number | null>(null);
  const [activeReadingBook, setActiveReadingBook] = useState<Book | null>(null);

  // --- BOOK RESERVATION STATE ---
  const [resDate, setResDate] = useState("");
  const [resStart, setResStart] = useState("10:00");
  const [resEnd, setResEnd] = useState("11:30");

  // --- STUDY TABLE RESERVATION STATE ---
  const [tableResDate, setTableResDate] = useState("");
  const [tableResStart, setTableResStart] = useState("12:00");
  const [tableResEnd, setTableResEnd] = useState("13:30");
  const [tableAssignMode, setTableAssignMode] = useState<"AUTO" | "MANUAL">("AUTO");
  const [selectedTableId, setSelectedTableId] = useState<number | "">("");

  // --- PROFILE UPDATE STATE ---
  const [pUsername, setPUsername] = useState(currentUser?.username || "");
  const [pPassword, setPPassword] = useState(currentUser?.password || "");
  const [pPhone, setPPhone] = useState(currentUser?.phone || "");
  const [pSeat, setPSeat] = useState(currentUser?.seatno || "");
  const [pMajor, setPMajor] = useState(currentUser?.major || "");
  const [pDept, setPDept] = useState(currentUser?.department || "");
  const [pDesig, setPDesig] = useState(currentUser?.designation || "");
  const [pPurpose, setPPurpose] = useState(currentUser?.purpose || "");
  const [topupAmount, setTopupAmount] = useState<string>("500");

  // Return Overdue simulator wizard state
  const [returningBookToSimulate, setReturningBookToSimulate] = useState<{ bookId: number; title: string } | null>(null);
  const [selectedSimulateLateMins, setSelectedSimulateLateMins] = useState<number>(0);

  if (!currentUser) return null;

  // Retrieve current categories
  const categories = ["ALL", ...Array.from(new Set(books.map(b => b.category)))];

  // Filtering books list
  const filteredBooksList = books.filter(b => {
    const textMatch = b.title.toLowerCase().includes(searchVal.toLowerCase()) || 
                      b.author.toLowerCase().includes(searchVal.toLowerCase());
    const catMatch = catFilter === "ALL" ? true : b.category === catFilter;
    return textMatch && catMatch;
  });

  const readerLimit = getEffectiveBorrowLimit(currentUser);
  const hasOverdue = hasOverdueBooks(currentUser);
  const overdueCount = getOverdueBooksCount(currentUser);

  // E-book Download micro-system simulation
  const startEbookDownload = (book: Book) => {
    if (downloadProgress !== null) return;
    setDownloadProgress(0);
    downloadBook(book.id);

    const interval = setInterval(() => {
      setDownloadProgress((prev) => {
        if (prev === null) return null;
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            setDownloadProgress(null);
            displayFeedback({ success: true, message: `Successfully downloaded PDF file: "${book.title}" in reference archives.` });
          }, 300);
          return 100;
        }
        return prev + 10;
      });
    }, 120);
  };

  const handleBorrowSubmit = (book: Book) => {
    if (borrowMinutes <= 0) {
      displayFeedback({ success: false, message: "Please specify a positive borrow term." });
      return;
    }
    const res = borrowBook(book.id, borrowMinutes);
    displayFeedback(res);
    if (res.success) {
      setSelectedBook(null);
    }
  };

  const handleReturnConfirm = () => {
    if (!returningBookToSimulate) return;
    const res = returnBook(returningBookToSimulate.bookId, selectedSimulateLateMins);
    displayFeedback(res);
    setReturningBookToSimulate(null);
    setSelectedSimulateLateMins(0);
  };

  const handleReserveBookSubmit = (book: Book) => {
    if (!resDate || !resStart || !resEnd) {
      displayFeedback({ success: false, message: "All booking details (Date, Start and End) are required." });
      return;
    }
    const res = reserveBookOnsite(book.id, resDate, resStart, resEnd);
    displayFeedback(res);
    if (res.success) {
      setResDate("");
      setSelectedBook(null);
    }
  };

  const handleTableReservationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!tableResDate || !tableResStart || !tableResEnd) {
      displayFeedback({ success: false, message: "Reservation Date and hours must be filled." });
      return;
    }

    if (tableAssignMode === "AUTO") {
      const res = reserveTableAuto(tableResDate, tableResStart, tableResEnd);
      displayFeedback(res);
    } else {
      if (!selectedTableId) {
        displayFeedback({ success: false, message: "Please select a study table." });
        return;
      }
      const res = reserveTableManual(Number(selectedTableId), tableResDate, tableResStart, tableResEnd);
      displayFeedback(res);
    }

    if (successMsg) {
      setTableResDate("");
      setSelectedTableId("");
    }
  };

  const triggerProfileUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    const phoneRegex = /^03\d{9}$/;
    if (!phoneRegex.test(pPhone)) {
      displayFeedback({ success: false, message: "Phone number syntax invalid! Standard format: 03xxxxxxxxx" });
      return;
    }

    const updates: any = {
      username: pUsername,
      password: pPassword,
      phone: pPhone,
      seatno: pSeat,
      major: pMajor,
      department: pDept,
      designation: pDesig,
      purpose: pPurpose
    };
    updateUserProfile(updates);
    displayFeedback({ success: true, message: "Reader profile variables updated successfully." });
  };

  const triggerWalletTopup = (e: React.FormEvent) => {
    e.preventDefault();
    const deposit = parseFloat(topupAmount) || 0;
    if (deposit < 10) {
      displayFeedback({ success: false, message: "Minimum wallet deposit threshold set at Rs. 10." });
      return;
    }
    addFunds(deposit);
    displayFeedback({ success: true, message: `Deposited Rs. ${deposit} into library wallet.` });
    setTopupAmount("500");
  };

  return (
    <div id="user-dashboard-wrapper" className="space-y-6">
      {/* 1. Header Grid, Profile Specs & Wallet card */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Profile Card */}
        <div className="lg:col-span-8 bg-gradient-to-br from-indigo-900 via-indigo-950 to-slate-950 text-white rounded-3xl p-6 md:p-8 shadow-sm border border-indigo-950 relative overflow-hidden flex flex-col justify-between">
          <div className="absolute top-0 right-0 w-48 h-48 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none transform translate-x-12 -translate-y-12" />
          
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-2">
              <span className={`text-[10px] font-bold tracking-widest uppercase font-mono px-2.5 py-1 rounded-full ${
                currentUser.type === "STUDENT" ? "bg-indigo-500/20 text-indigo-200 border border-indigo-400/30" :
                currentUser.type === "FACULTY" ? "bg-emerald-500/20 text-emerald-200 border border-emerald-400/30" :
                "bg-violet-500/20 text-indigo-200 border border-violet-400/30"
              }`}>
                {currentUser.type === "STUDENT" && "🎓 Student Card"}
                {currentUser.type === "FACULTY" && "💼 Faculty Card"}
                {currentUser.type === "GUEST" && "👤 Guest Reference Pass"}
              </span>

              {currentUser.membership?.active ? (
                <span className="bg-amber-500/20 text-amber-300 text-[10px] font-bold tracking-widest uppercase border border-amber-400/30 px-2.5 py-1 rounded-full flex items-center gap-1">
                  <Award className="w-3.5 h-3.5 fill-amber-300 text-amber-300" />
                  Premium Member
                </span>
              ) : (
                <span className="text-indigo-400 text-[10px] font-mono">Standard Desk Account</span>
              )}
            </div>

            <div>
              <h2 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
                Hello, {currentUser.name}!
              </h2>
              <p className="text-indigo-200/60 text-xs mt-0.5">Linked email: {currentUser.email} • CNIC: {currentUser.cnic}</p>
            </div>

            {/* Warn banners if Overdue book exists */}
            {hasOverdue && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl text-rose-300 text-[11px] leading-relaxed flex items-start gap-2.5">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <div>
                  <b className="block font-bold">Overdue Notice</b>
                  You have {overdueCount} book return(s) past due! Further lending operations are restricted until books are resolved.
                </div>
              </div>
            )}
            
            {currentUser.balance <= -500 && (
              <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl text-amber-300 text-[11px] leading-relaxed flex items-start gap-2.5">
                <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <b className="block">Outstanding Debt Block</b>
                  Card account has generated a negative balance beyond Rs. 500 limit. Please credit your account below to resume lending.
                </div>
              </div>
            )}
          </div>

          {/* Quick specs metrics */}
          <div className="grid grid-cols-3 gap-3 border-t border-indigo-500/10 pt-6 mt-6">
            <div className="font-mono">
              <span className="text-indigo-300/60 text-[10px] uppercase font-bold tracking-wider">Borrows quota</span>
              <span className="text-lg font-bold text-white block mt-0.5">{currentUser.borrowedIds?.length || 0} / {readerLimit}</span>
            </div>
            <div className="font-mono">
              <span className="text-indigo-300/60 text-[10px] uppercase font-bold tracking-wider">Fine rate</span>
              <span className="text-lg font-bold text-white block mt-0.5">Rs. {currentUser.type === "STUDENT" ? 10 : currentUser.type === "FACULTY" ? 15 : 20} / min</span>
            </div>
            <div className="font-mono">
              <span className="text-indigo-300/60 text-[10px] uppercase font-bold tracking-wider">Dynamic Fines Paid</span>
              <span className="text-lg font-bold text-emerald-400 block mt-0.5">Rs. {currentUser.total_fines_paid}</span>
            </div>
          </div>
        </div>

        {/* Library Card Wallet Topup module */}
        <div className="lg:col-span-4 bg-white border border-slate-100 p-6 rounded-3xl flex flex-col justify-between shadow-xs">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 font-mono">My Account Wallet</span>
            <div className="flex items-center gap-2 mt-2 mb-4">
              <Wallet className="w-6 h-6 text-indigo-500 shrink-0" />
              <span className={`text-2xl font-extrabold ${currentUser.balance < 0 ? "text-rose-500" : "text-slate-800"}`}>
                Rs. {currentUser.balance}
              </span>
            </div>

            <p className="text-slate-500 text-xs leading-relaxed mb-4">
              Fines are automatically deducted from library card deposit balance. Maintain positive balance to avoid lending blocks.
            </p>
          </div>

          <form onSubmit={triggerWalletTopup} className="space-y-2 border-t border-slate-50 pt-4">
            <label className="text-[10px] font-bold tracking-wider uppercase text-slate-400 font-mono block">Top-Up Credit</label>
            <div className="flex gap-2">
              <input
                type="number"
                min="10"
                value={topupAmount}
                onChange={(e) => setTopupAmount(e.target.value)}
                placeholder="Rs."
                className="flex-1 px-3 py-1.5 bg-slate-50 border border-slate-100 rounded-lg text-xs font-medium focus:outline-none focus:bg-white"
              />
              <button
                type="submit"
                className="bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg px-4 py-2 text-xs font-bold transition duration-150 cursor-pointer shrink-0"
              >
                Add Credit
              </button>
            </div>
          </form>
        </div>

      </div>

      {/* Notifications widgets */}
      {successMsg && (
        <div className="p-4 bg-emerald-50 border border-emerald-100/60 rounded-xl text-emerald-700 text-xs font-semibold flex items-center gap-2">
          <Check className="w-5 h-5 text-emerald-500" />
          <span>{successMsg}</span>
        </div>
      )}
      {errorMsg && (
        <div className="p-4 bg-rose-50 border border-rose-100/60 rounded-xl text-rose-700 text-xs font-semibold flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-rose-500" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Selector Panels Subtabs */}
      <div className="flex border-b border-slate-100 gap-1 overflow-x-auto pb-0.5 font-medium">
        <button
          onClick={() => setActiveTab("SEARCH")}
          className={`px-4 py-2.5 text-sm rounded-t-xl transition-all flex items-center gap-2 shrink-0 cursor-pointer ${
            activeTab === "SEARCH" ? "bg-slate-50 text-slate-900 border-t-2 border-indigo-600 font-bold" : "text-slate-400 hover:text-slate-600"
          }`}
        >
          <Search className="w-4.5 h-4.5" /> Book Desk catalog
        </button>
        <button
          onClick={() => setActiveTab("MY_BORROWS")}
          className={`px-4 py-2.5 text-sm rounded-t-xl transition-all flex items-center gap-2 shrink-0 cursor-pointer ${
            activeTab === "MY_BORROWS" ? "bg-slate-50 text-slate-900 border-t-2 border-indigo-600 font-bold" : "text-slate-400 hover:text-slate-600"
          }`}
        >
          <BookOpen className="w-4.5 h-4.5" /> Checked-Out List ({currentUser.borrowedIds?.length || 0})
        </button>
        <button
          onClick={() => setActiveTab("RESERVATIONS")}
          className={`px-4 py-2.5 text-sm rounded-t-xl transition-all flex items-center gap-2 shrink-0 cursor-pointer ${
            activeTab === "RESERVATIONS" ? "bg-slate-50 text-slate-900 border-t-2 border-indigo-600 font-bold" : "text-slate-400 hover:text-slate-600"
          }`}
        >
          <Calendar className="w-4.5 h-4.5" /> Study Room Reserv.
        </button>
        <button
          onClick={() => setActiveTab("MEMBERSHIP")}
          className={`px-4 py-2.5 text-sm rounded-t-xl transition-all flex items-center gap-2 shrink-0 cursor-pointer ${
            activeTab === "MEMBERSHIP" ? "bg-slate-50 text-slate-900 border-t-2 border-indigo-600 font-bold" : "text-slate-400 hover:text-slate-600"
          }`}
        >
          <Sparkles className="w-4.5 h-4.5" /> Membership Hub
        </button>
        <button
          onClick={() => setActiveTab("UPDATE_PROFILE")}
          className={`px-4 py-2.5 text-sm rounded-t-xl transition-all flex items-center gap-2 shrink-0 cursor-pointer ${
            activeTab === "UPDATE_PROFILE" ? "bg-slate-50 text-slate-900 border-t-2 border-indigo-600 font-bold" : "text-slate-400 hover:text-slate-600"
          }`}
        >
          <User className="w-4.5 h-4.5" /> Profile Settings
        </button>

        <button
          onClick={logout}
          className="ml-auto text-rose-500 hover:bg-rose-50 transition border border-rose-100 rounded-lg px-3 py-1.5 text-xs font-semibold flex items-center gap-1.5 shrink-0 cursor-pointer"
        >
          <LogOut className="w-3.5 h-3.5" /> Check-out Desk
        </button>
      </div>

      {/* TAB INTERNALS */}

      {/* 1. CATALOG SEARCH AND LENDING */}
      {activeTab === "SEARCH" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main search pane */}
          <div className="lg:col-span-2 space-y-4">
            <div className="bg-white border border-slate-100 p-5 rounded-3xl flex flex-col md:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3.5 top-3 w-4.5 h-4.5 text-slate-400" />
                <input
                  type="text"
                  value={searchVal}
                  onChange={(e) => setSearchVal(e.target.value)}
                  placeholder="Filter by title, author, keyword..."
                  className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-100 rounded-xl text-xs font-medium focus:outline-none focus:bg-white"
                />
              </div>

              {/* Category Filter lists */}
              <div className="flex gap-1 overflow-x-auto bg-slate-50 p-1 border border-slate-100 rounded-xl max-w-xs shrink-0 select-none">
                {categories.slice(0, 4).map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setCatFilter(cat)}
                    className={`px-3 py-1.5 text-[10px] font-bold tracking-wider rounded-lg uppercase shrink-0 cursor-pointer ${
                      catFilter === cat ? "bg-white text-slate-800 shadow-xs" : "text-slate-400 hover:text-slate-700"
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Book Lists Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {filteredBooksList.map((book) => (
                <div
                  key={book.id}
                  onClick={() => setSelectedBook(book)}
                  className={`bg-white border rounded-3xl p-5 hover:border-indigo-500 cursor-pointer transition-all duration-200 relative overflow-hidden group ${
                    selectedBook?.id === book.id ? "border-indigo-600 shadow-sm" : "border-slate-100"
                  }`}
                >
                  <div className="absolute top-0 right-0 w-24 h-24 bg-slate-50 rounded-full blur-xl opacity-0 group-hover:opacity-100 pointer-events-none transform translate-x-1/2 -translate-y-1/2 transition" />
                  
                  <div className="flex justify-between items-start mb-2.5">
                    <span className="bg-slate-50 border border-slate-100 text-[10px] text-slate-500 px-2 py-0.5 rounded-md font-medium">
                      {book.category}
                    </span>
                    <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full ${book.copies > 0 ? "bg-emerald-50 text-emerald-600" : "bg-rose-50 text-rose-500"}`}>
                      {book.copies > 0 ? `${book.copies} In Stock` : "Unavailable"}
                    </span>
                  </div>

                  <h3 className="font-bold text-slate-800 text-sm leading-snug group-hover:text-indigo-600 transition truncate-2-lines">
                    {book.title}
                  </h3>
                  <p className="text-slate-400 text-xs font-medium mt-0.5">by {book.author}</p>

                  <div className="mt-4 pt-3.5 border-t border-slate-50 flex items-center justify-between font-mono text-[10px] text-slate-400">
                    <span>ISBN: {book.isbn}</span>
                    <span className="flex items-center gap-0.5 text-indigo-500 font-bold">
                      View Actions
                      <ChevronRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Book Details and action console */}
          <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-xs self-start">
            {selectedBook ? (
              <div className="space-y-6">
                <div>
                  <span className="text-[10px] font-bold text-indigo-500 uppercase tracking-widest font-mono">Book Details console</span>
                  <h3 className="text-lg font-bold text-slate-800 leading-snug mt-1">{selectedBook.title}</h3>
                  <p className="text-slate-400 text-xs mt-0.5">by <span className="text-slate-600 font-semibold">{selectedBook.author}</span></p>
                </div>

                <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100/60 font-mono text-xs text-slate-500 space-y-2.5">
                  <div className="flex justify-between">
                    <span>Publisher:</span>
                    <span className="text-slate-800 font-medium">{selectedBook.publisher} ({selectedBook.year})</span>
                  </div>
                  <div className="flex justify-between">
                    <span>ISBN System:</span>
                    <span className="text-slate-800">{selectedBook.isbn}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Copy Stock:</span>
                    <span className={`font-bold ${selectedBook.copies > 0 ? "text-slate-800" : "text-rose-500"}`}>
                      {selectedBook.copies} Available copies
                    </span>
                  </div>
                </div>

                {/* Micro Actions Bar */}
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => {
                      readOnSite(selectedBook.id);
                      setActiveReadingBook(selectedBook);
                    }}
                    className="flex items-center justify-center gap-1.5 border border-slate-150 rounded-xl py-2 px-3 text-xs font-bold text-slate-600 hover:bg-slate-50 transition shrink-0 cursor-pointer"
                  >
                    <Eye className="w-4 h-4 text-indigo-500" />
                    On-Site Read
                  </button>
                  <button
                    onClick={() => startEbookDownload(selectedBook)}
                    disabled={downloadProgress !== null}
                    className="flex items-center justify-center gap-1.5 border border-slate-150 rounded-xl py-2 px-3 text-xs font-bold text-slate-600 hover:bg-slate-50 disabled:opacity-50 transition shrink-0 cursor-pointer"
                  >
                    <Download className="w-4 h-4 text-emerald-500 animate-pulse" />
                    Download PDF
                  </button>
                </div>

                {/* Progress Download micro simulator bar */}
                {downloadProgress !== null && (
                  <div className="space-y-1.5 p-3 bg-slate-50 rounded-xl border border-slate-100">
                    <div className="flex justify-between text-[10px] font-mono text-slate-500 font-bold">
                      <span className="flex items-center gap-1 text-emerald-600">
                        <Download className="w-3.5 h-3.5" /> Pulling payload from index...
                      </span>
                      <span>{downloadProgress}%</span>
                    </div>
                    <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                      <div className="h-full bg-emerald-500 rounded-full transition-all" style={{ width: `${downloadProgress}%` }} />
                    </div>
                  </div>
                )}

                {/* On-Site Borrow Slider and Trigger */}
                <div className="border-t border-slate-50 pt-5 space-y-4">
                  <div>
                    <div className="flex justify-between mb-1">
                      <label className="text-[10px] font-bold tracking-wider uppercase text-slate-400 font-mono">Borrow Duration (Minutes)</label>
                      <span className="text-xs font-mono font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-md">
                        {borrowMinutes} Mins
                      </span>
                    </div>
                    <input
                      type="range"
                      min="5"
                      max="120"
                      step="5"
                      value={borrowMinutes}
                      onChange={(e) => setBorrowMinutes(Number(e.target.value))}
                      className="w-full h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                    />
                  </div>

                  <button
                    onClick={() => handleBorrowSubmit(selectedBook)}
                    disabled={selectedBook.copies <= 0 || hasOverdue || currentUser.balance <= -500}
                    className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-100 disabled:text-slate-400 text-white font-bold text-xs uppercase tracking-wide py-3 rounded-xl transition duration-150 flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <BookOpen className="w-4 h-4" />
                    Confirm Check-Out
                  </button>
                </div>

                {/* Register Table Onsite reservation for the selection book */}
                <div className="border-t border-slate-50 pt-5 space-y-3">
                  <h4 className="text-[10px] font-bold tracking-wider uppercase text-slate-400 font-mono">Reserve Library Desk Copies</h4>
                  
                  <div className="space-y-2">
                    <input
                      type="text"
                      placeholder="Reservation Date DD/MM/YYYY"
                      value={resDate}
                      onChange={(e) => setResDate(e.target.value)}
                      className="w-full px-3 py-1.5 bg-slate-50 border border-slate-100 rounded-lg text-xs font-mono"
                    />
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        type="text"
                        placeholder="Start HH:MM"
                        value={resStart}
                        onChange={(e) => setResStart(e.target.value)}
                        className="px-3 py-1.5 bg-slate-50 border border-slate-100 rounded-lg text-xs font-mono"
                      />
                      <input
                        type="text"
                        placeholder="End HH:MM"
                        value={resEnd}
                        onChange={(e) => setResEnd(e.target.value)}
                        className="px-3 py-1.5 bg-slate-50 border border-slate-100 rounded-lg text-xs font-mono"
                      />
                    </div>
                  </div>

                  <button
                    onClick={() => handleReserveBookSubmit(selectedBook)}
                    disabled={selectedBook.copies <= 0 || hasOverdue || currentUser.balance <= -500}
                    className="w-full bg-slate-850 hover:bg-slate-900 border border-slate-800 disabled:bg-slate-100 text-white py-2.5 rounded-xl text-xs font-bold transition cursor-pointer"
                  >
                    Reserve On-Site Copies
                  </button>
                </div>

              </div>
            ) : (
              <div className="text-center py-16 text-slate-400 font-mono text-xs">
                Select a book card to open parameters and lending check-outs.
              </div>
            )}
          </div>
        </div>
      )}

      {/* 2. CHECKED OUT LIST & OVERDUE SIMULATOR RETURNS */}
      {activeTab === "MY_BORROWS" && (
        <div className="max-w-2xl mx-auto bg-white border border-slate-100 p-6 rounded-3xl shadow-xs">
          <div className="border-b border-slate-100 pb-4 mb-4">
            <h3 className="font-bold text-slate-800 text-base">Checked-Out Library Archives</h3>
            <p className="text-slate-500 text-xs mt-0.5">Active borrow logs. Click Return Book to open late invoice simulations.</p>
          </div>

          <div className="divide-y divide-slate-100 space-y-4">
            {transactions.filter(t => t.uid === currentUser.id && !t.returned).map((t) => {
              const book = bMap.get(t.bid);
              const due = new Date(t.due_time);
              const now = new Date();
              const isOverdue = due < now;

              return (
                <div key={t.tid} className="py-4 flex justify-between items-start gap-4">
                  <div className="min-w-0">
                    <span className="text-slate-400 text-[10px] font-mono leading-none block mb-1">TXID #{t.tid}</span>
                    <h4 className="font-bold text-slate-800 text-sm truncate">{book?.title || "Unknown Book"}</h4>
                    <p className="text-slate-400 text-xs mt-0.5">by {book?.author}</p>

                    <div className="flex items-center gap-1.5 mt-2 text-[10px] font-mono text-slate-500">
                      <span>Borrowed: {new Date(t.borrow_time).toLocaleTimeString()}</span>
                      <span>•</span>
                      <span>Due Term: {due.toLocaleTimeString()}</span>
                    </div>
                  </div>

                  <div className="shrink-0 text-right flex flex-col items-end gap-2.5">
                    <span className={`px-2 py-0.5 text-[9px] font-bold tracking-wider uppercase font-mono rounded-full ${
                      isOverdue ? "bg-rose-50 text-rose-600 border border-rose-100" : "bg-indigo-50 text-indigo-600 border border-indigo-100"
                    }`}>
                      {isOverdue ? "LATE OVERDUE" : "ACTIVE CHECKED-OUT"}
                    </span>

                    <button
                      onClick={() => setReturningBookToSimulate({ bookId: t.bid, title: book?.title || "Book" })}
                      className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl px-3.5 py-1.5 transition duration-150 cursor-pointer shadow-xs whitespace-nowrap"
                    >
                      Return Book
                    </button>
                  </div>
                </div>
              );
            })}

            {transactions.filter(t => t.uid === currentUser.id && !t.returned).length === 0 && (
              <div className="text-center py-12 text-slate-400 font-mono text-xs">
                You do not have any borrowed libraries active. Search below to add references!
              </div>
            )}
          </div>
        </div>
      )}

      {/* 3. STUDY ROOM RESERVATIONS */}
      {activeTab === "RESERVATIONS" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Booking Study Room Form */}
          <div className="lg:col-span-4 bg-white border border-slate-100 p-6 rounded-3xl shadow-xs self-start">
            <h3 className="font-bold text-slate-800 text-base mb-4 flex items-center gap-1.5">
              <Calendar className="text-indigo-500 w-5 h-5" />
              Book Study desk
            </h3>

            <form onSubmit={handleTableReservationSubmit} className="space-y-4">
              <div>
                <label className="text-[10px] font-bold tracking-wider uppercase text-slate-400 font-mono block mb-1">Date [DD/MM/YYYY]</label>
                <input
                  type="text"
                  required
                  value={tableResDate}
                  onChange={(e) => setTableResDate(e.target.value)}
                  placeholder="e.g. 20/05/2026"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-100 rounded-xl text-slate-700 text-xs font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-bold tracking-wider uppercase text-slate-400 font-mono block mb-1">Start Time</label>
                  <input
                    type="text"
                    required
                    value={tableResStart}
                    onChange={(e) => setTableResStart(e.target.value)}
                    placeholder="e.g. 12:00"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-100 rounded-xl text-slate-700 text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold tracking-wider uppercase text-slate-400 font-mono block mb-1">End Time</label>
                  <input
                    type="text"
                    required
                    value={tableResEnd}
                    onChange={(e) => setTableResEnd(e.target.value)}
                    placeholder="e.g. 13:30"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-100 rounded-xl text-slate-700 text-xs font-mono"
                  />
                </div>
              </div>

              {/* Assignment Mode toggles */}
              <div className="border-t border-slate-50 pt-3">
                <label className="text-[10px] font-bold tracking-wider uppercase text-slate-400 font-mono block mb-2">Assignment Strategy</label>
                <div className="grid grid-cols-2 gap-2 bg-slate-50 p-1 border border-slate-100 rounded-xl select-none text-[11px] font-bold">
                  <button
                    type="button"
                    onClick={() => setTableAssignMode("AUTO")}
                    className={`py-1.5 rounded-lg text-center transition cursor-pointer ${tableAssignMode === "AUTO" ? "bg-white text-slate-800 shadow-xs" : "text-slate-400 hover:text-slate-700"}`}
                  >
                    Auto-Allocate
                  </button>
                  <button
                    type="button"
                    onClick={() => setTableAssignMode("MANUAL")}
                    className={`py-1.5 rounded-lg text-center transition cursor-pointer ${tableAssignMode === "MANUAL" ? "bg-white text-slate-800 shadow-xs" : "text-slate-400 hover:text-slate-700"}`}
                  >
                    Manual Select
                  </button>
                </div>
              </div>

              {tableAssignMode === "MANUAL" && (
                <div>
                  <label className="text-[10px] font-bold tracking-wider uppercase text-slate-400 font-mono block mb-1.5 animate-fade-in">Select Desired Hall</label>
                  <select
                    value={selectedTableId}
                    onChange={(e) => setSelectedTableId(e.target.value !== "" ? Number(e.target.value) : "")}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-100 rounded-xl text-xs font-medium focus:outline-none"
                  >
                    <option value="">-- Choose Study Room Table --</option>
                    {tables.map(t => (
                      <option key={t.id} value={t.id}>
                        Table #{t.id} ({t.location}) (Limit {t.capacity} seats)
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <button
                type="submit"
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs uppercase tracking-wide py-3 rounded-xl transition duration-150 cursor-pointer mt-2"
              >
                Register study window
              </button>
            </form>
          </div>

          {/* Reserved list pane index */}
          <div className="lg:col-span-8 bg-white border border-slate-100 p-6 rounded-3xl shadow-xs">
            <h3 className="font-bold text-slate-800 text-base mb-4">My Booked Slots Reserv.</h3>
            
            <div className="space-y-4">
              {reservations.filter(r => r.userid === currentUser.id && r.active).map((res) => {
                const isBook = res.bookid > 0;
                const bookItem = isBook ? bMap.get(res.bookid) : null;
                const deskItem = !isBook ? tableMap.get(res.tableid) : null;

                return (
                  <div key={res.reservationid} className="border border-slate-100 rounded-2xl p-4 flex justify-between items-center gap-4 hover:border-indigo-100 transition">
                    <div>
                      <span className={`text-[10px] font-bold tracking-wider uppercase font-mono px-2 py-0.5 rounded-full ${isBook ? "bg-indigo-50 text-indigo-600" : "bg-amber-50 text-amber-600"}`}>
                        {isBook ? "Book Copy Reserv." : "Study Desk Reservation"}
                      </span>

                      <h4 className="font-bold text-slate-800 text-sm mt-2 leading-snug">
                        {isBook ? bookItem?.title : `Hall Study Room (Table #${res.tableid})`}
                      </h4>
                      <p className="text-slate-400 text-xs font-medium mt-0.5">
                        {isBook ? `by ${bookItem?.author}` : deskItem?.location}
                      </p>

                      <div className="flex items-center gap-1.5 mt-2.5 font-mono text-[10px] text-slate-500">
                        <span>Date: {res.date}</span>
                        <span>•</span>
                        <span>Slot: {res.startTime} to {res.endTime}</span>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        if (confirm("Revoke/Cancel this reservation?")) {
                          cancelReservation(res.reservationid);
                          displayFeedback({ success: true, message: "Reservation cancelled." });
                        }
                      }}
                      className="bg-rose-50 hover:bg-rose-100 text-rose-600 text-[11px] font-bold rounded-xl px-3.5 py-1.5 shrink-0 transition cursor-pointer"
                    >
                      Cancel
                    </button>
                  </div>
                );
              })}

              {reservations.filter(r => r.userid === currentUser.id && r.active).length === 0 && (
                <div className="text-center py-16 text-slate-400 font-mono text-xs">
                  No active on-site bookings currently.
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 4. PREMIUM MEMBERSHIP HUB */}
      {activeTab === "MEMBERSHIP" && (
        <div className="max-w-2xl mx-auto bg-white border border-slate-100 rounded-3xl p-6 md:p-8 shadow-xs">
          <div className="text-center max-w-md mx-auto mb-8">
            <span className="text-[10px] font-bold tracking-widest text-indigo-500 uppercase font-mono">Unlock full capabilities</span>
            <h3 className="text-2xl font-black tracking-tight text-slate-850 mt-1">Premium Redora Membership</h3>
            <p className="text-slate-500 text-sm mt-1">Join top tier researchers for boosted borrowing quotas and overdue fines discounts.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 my-6">
            <div className="bg-slate-50 border border-slate-100 p-5 rounded-2xl">
              <span className="text-[10px] font-bold text-slate-400 uppercase font-mono tracking-wide">Current Limits</span>
              <ul className="mt-3.5 space-y-2 text-xs font-medium text-slate-600 leading-none">
                <li className="flex justify-between">
                  <span>Borrow Cap:</span>
                  <span className="font-mono font-bold text-slate-800">
                    {currentUser.type === "STUDENT" ? 3 : currentUser.type === "FACULTY" ? 5 : 1} concurrent
                  </span>
                </li>
                <li className="flex justify-between border-t border-slate-100/50 pt-2 text-rose-500">
                  <span>Late Fines Invoice:</span>
                  <span>100% Rate Applied</span>
                </li>
              </ul>
            </div>

            <div className="bg-gradient-to-br from-amber-50 to-amber-100 border border-amber-200/50 p-5 rounded-2xl relative shadow-xs">
              <span className="text-[10px] font-bold text-amber-700 uppercase font-mono tracking-wide flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" />
                Premium Quotas Boost
              </span>
              <ul className="mt-3.5 space-y-2 text-xs font-semibold text-amber-900 leading-none">
                <li className="flex justify-between">
                  <span>Quota limit:</span>
                  <span className="font-mono font-bold text-amber-950">
                    {currentUser.type === "STUDENT" ? 5 : currentUser.type === "FACULTY" ? 7 : 2} concurrent
                  </span>
                </li>
                <li className="flex justify-between border-t border-amber-200/30 pt-2 text-emerald-700">
                  <span>Overdue Assessed Fines:</span>
                  <span>15% Special Discount</span>
                </li>
              </ul>
            </div>
          </div>

          {currentUser.membership?.active ? (
            <div className="space-y-4 border-t border-slate-50 pt-6 mt-6">
              <div className="p-4 bg-amber-50 border border-amber-200/50 rounded-xl text-amber-800 text-xs font-medium leading-relaxed">
                🎉 Your Redora card has Premium Membership activated! Expiration expected on: <b>{new Date(currentUser.membership.expiryTime).toLocaleDateString()}</b>.
              </div>
              <button
                onClick={() => {
                  if (confirm("Terminate Premium Membership? Limits will fall instantly.")) {
                    cancelMembership();
                    displayFeedback({ success: true, message: "Membership cancelled." });
                  }
                }}
                className="w-full bg-rose-50 hover:bg-rose-100 text-rose-600 font-bold text-xs py-3 rounded-xl transition cursor-pointer"
              >
                Terminate Card Membership
              </button>
            </div>
          ) : (
            <div className="space-y-4 border-t border-slate-50 pt-6 mt-6">
              <div className="p-4 bg-slate-50 border border-slate-100 rounded-xl text-slate-500 text-xs text-center">
                Annual Subscription activates instant variables changes. <b>Cost: Rs. 0 value mock activation test.</b>
              </div>
              <button
                onClick={() => {
                  activateMembership();
                  displayFeedback({ success: true, message: "Redora Premium activated! Enjoy limits increase and discounts." });
                }}
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs uppercase tracking-wide py-3.5 rounded-xl transition duration-150 cursor-pointer shadow-xs"
              >
                Join Premium Alliance
              </button>
            </div>
          )}
        </div>
      )}

      {/* 5. UPDATE ACCOUNT DATA */}
      {activeTab === "UPDATE_PROFILE" && (
        <div className="max-w-xl mx-auto bg-white border border-slate-100 rounded-3xl p-6 shadow-xs">
          <div className="border-b border-slate-100 pb-4 mb-5">
            <h3 className="font-bold text-slate-800 text-base">Update Account File</h3>
            <p className="text-slate-500 text-xs mt-0.5">Maintain card member files including usernames and access pins.</p>
          </div>

          <form onSubmit={triggerProfileUpdate} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] font-bold text-slate-400 font-mono block mb-1 uppercase tracking-wide">Username</label>
                <input
                  type="text"
                  required
                  value={pUsername}
                  onChange={(e) => setPUsername(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-100 rounded-lg text-xs font-semibold focus:outline-none focus:bg-white focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-400 font-mono block mb-1 uppercase tracking-wide">Secured Pin / Pass</label>
                <input
                  type="password"
                  required
                  value={pPassword}
                  onChange={(e) => setPPassword(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-100 rounded-lg text-xs font-semibold focus:outline-none focus:bg-white focus:border-indigo-500"
                />
              </div>
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-400 font-mono block mb-1 uppercase tracking-wide">Reader Phone [03xxxxxxxxx]</label>
              <input
                type="text"
                required
                value={pPhone}
                onChange={(e) => setPPhone(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-100 rounded-lg text-xs font-semibold focus:outline-none focus:bg-white focus:border-indigo-500"
              />
            </div>

            {/* Type Specific Fields Forms */}
            {currentUser.type === "STUDENT" && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 border-t border-slate-50 pt-3">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 font-mono block mb-1 uppercase tracking-wide">Seat number</label>
                  <input
                    type="text"
                    required
                    value={pSeat}
                    onChange={(e) => setPSeat(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-100 rounded-lg text-xs focus:outline-none focus:bg-white focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 font-mono block mb-1 uppercase tracking-wide">Major Dept</label>
                  <input
                    type="text"
                    required
                    value={pMajor}
                    onChange={(e) => setPMajor(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-100 rounded-lg text-xs focus:outline-none"
                  />
                </div>
              </div>
            )}

            {currentUser.type === "FACULTY" && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 border-t border-slate-50 pt-3">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 font-mono block mb-1 uppercase tracking-wide">Department</label>
                  <input
                    type="text"
                    required
                    value={pDept}
                    onChange={(e) => setPDept(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-100 rounded-lg text-xs focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 font-mono block mb-1 uppercase tracking-wide">Faculty Designation</label>
                  <input
                    type="text"
                    required
                    value={pDesig}
                    onChange={(e) => setPDesig(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-100 rounded-lg text-xs focus:outline-none"
                  />
                </div>
              </div>
            )}

            {currentUser.type === "GUEST" && (
              <div className="border-t border-slate-50 pt-3">
                <label className="text-[10px] font-bold text-slate-400 font-mono block mb-1 uppercase tracking-wide">Access purpose</label>
                <input
                  type="text"
                  required
                  value={pPurpose}
                  onChange={(e) => setPPurpose(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-100 rounded-lg text-xs focus:outline-none"
                />
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-slate-850 hover:bg-slate-900 text-white font-bold text-xs uppercase tracking-wide py-3.5 rounded-xl transition duration-150 cursor-pointer"
            >
              Commit Updates
            </button>
          </form>
        </div>
      )}

      {/* OVERDUE INVOICE SIMULATOR DIALOG / MODAL */}
      {returningBookToSimulate && (
        <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center p-4 z-50 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full border border-slate-150 shadow-lg space-y-5">
            <div>
              <div className="inline-flex w-10 h-10 rounded-lg bg-indigo-50 text-indigo-500 items-center justify-center mb-2 shrink-0">
                <Clock className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-slate-800 leading-tight">Simulate return timeline delay</h3>
              <p className="text-slate-500 text-xs mt-0.5">Select a delayed returning timestamp to test assessed fees, margins, and membership discounts.</p>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 font-mono text-xs text-slate-500 leading-relaxed">
              Book: <b className="text-slate-800">{returningBookToSimulate.title}</b>
            </div>

            {/* Choose late delay simulated values */}
            <div className="grid grid-cols-2 gap-2 text-xs font-semibold">
              <button
                onClick={() => setSelectedSimulateLateMins(0)}
                className={`p-2.5 rounded-xl border text-center transition cursor-pointer ${selectedSimulateLateMins === 0 ? "bg-emerald-50 text-emerald-700 border-emerald-300" : "bg-white text-slate-600 border-slate-150 hover:bg-slate-55"}`}
              >
                On-Time (Rs. 0 fine)
              </button>
              <button
                onClick={() => setSelectedSimulateLateMins(30)}
                className={`p-2.5 rounded-xl border text-center transition cursor-pointer ${selectedSimulateLateMins === 30 ? "bg-rose-50 text-rose-700 border-rose-300" : "bg-white text-slate-600 border-slate-150 hover:bg-slate-55"}`}
              >
                30 Mins Late
              </button>
              <button
                onClick={() => setSelectedSimulateLateMins(120)}
                className={`p-2.5 rounded-xl border text-center transition cursor-pointer ${selectedSimulateLateMins === 120 ? "bg-rose-50 text-rose-700 border-rose-300" : "bg-white text-slate-600 border-slate-150 hover:bg-slate-55"}`}
              >
                2 Hrs Late
              </button>
              <button
                onClick={() => setSelectedSimulateLateMins(1440)}
                className={`p-2.5 rounded-xl border text-center transition cursor-pointer ${selectedSimulateLateMins === 1440 ? "bg-rose-50 text-rose-700 border-rose-300" : "bg-white text-slate-600 border-slate-150 hover:bg-slate-55"}`}
              >
                24 Hours Late
              </button>
            </div>

            {/* Simulated Live Fine Box */}
            <div className="border-t border-slate-50 pt-4 font-mono text-xs flex justify-between items-center text-slate-500">
              <span>Assessed dynamic Fine:</span>
              <span className={`text-sm font-bold ${selectedSimulateLateMins > 0 ? "text-rose-500" : "text-emerald-600"}`}>
                Rs. {selectedSimulateLateMins * (currentUser.type === "STUDENT" ? 10 : currentUser.type === "FACULTY" ? 15 : 20) * (currentUser.membership?.active ? 0.85 : 1)}
                {currentUser.membership?.active && selectedSimulateLateMins > 0 && <span className="text-[9px] block text-amber-600 leading-none">15% discount applied!</span>}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3.5 pt-4">
              <button
                onClick={() => setReturningBookToSimulate(null)}
                className="border border-slate-150 rounded-xl py-2 px-3 text-xs font-bold text-slate-500 hover:bg-slate-50 transition cursor-pointer"
              >
                Close popup
              </button>
              <button
                onClick={handleReturnConfirm}
                className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl py-2 px-3 transition cursor-pointer"
              >
                Commit Return check-in
              </button>
            </div>
          </div>
        </div>
      )}

      {/* INTERACTIVE ONSITE BOOK READING SIMULATION INTERFACE MODAL */}
      {activeReadingBook && (
        <div className="fixed inset-0 bg-slate-950/80 flex items-center justify-center p-4 z-50 backdrop-blur-md animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 text-slate-200 rounded-3xl p-6 md:p-8 max-w-2xl w-full flex flex-col justify-between space-y-6">
            <div className="flex justify-between items-start border-b border-slate-800 pb-4">
              <div>
                <span className="text-[10px] font-bold font-mono tracking-widest text-indigo-400 uppercase">On-Site E-Reader System active</span>
                <h3 className="text-lg font-black text-white mt-1 leading-tight">{activeReadingBook.title}</h3>
                <p className="text-slate-400 text-xs">by {activeReadingBook.author} • Index {activeReadingBook.isbn}</p>
              </div>
              <button
                onClick={() => setActiveReadingBook(null)}
                className="text-slate-400 hover:text-white transition p-1.5 hover:bg-slate-800 rounded-lg shrink-0 cursor-pointer"
              >
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            {/* Read block preview screens */}
            <div className="bg-slate-950/80 border border-slate-850 p-5 rounded-2xl font-sans text-xs leading-relaxed text-slate-300 max-h-[300px] overflow-y-auto space-y-4">
              <p className="font-semibold text-white uppercase tracking-wider text-[10px] font-mono">[CHAPTER I - INTRODUCTION TO SUBJECT ELEMENTS]</p>
              <p>
                In academic investigation, references constitute the structural pillars on which rigorous scientific formulations depend. 
                Whether we trace historical structures in Orwellian dystopian prose, compile complex computational vectors using Cornen's
                algorithms, or design architectures with Clean Code methodologies, the storage infrastructure of knowledge defines outcomes.
              </p>
              <p>
                This simulated reading session increments the on-site statistics meter on the dashboard dynamically. This is a fully pre-compiled 
                GUI designed to evaluate all components safely in container architectures.
              </p>
              <p className="italic text-slate-400 text-[11px]">
                "The library is a fortress storing collective human discoveries. Access is a privilege governed by rules."
              </p>
            </div>

            <div className="flex items-center justify-between text-xs text-slate-400 border-t border-slate-800 pt-4">
              <span className="flex items-center gap-1">
                <Flame className="w-4 h-4 text-orange-400 shrink-0" />
                Read index count: <span className="font-bold text-white font-mono">{activeReadingBook.read_onsite_count + 1} onsite uses</span>
              </span>
              <button
                onClick={() => setActiveReadingBook(null)}
                className="bg-slate-800 hover:bg-slate-700 text-white rounded-xl py-2 px-5 text-xs font-bold transition duration-150 cursor-pointer"
              >
                Close Interactive Session
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
