import React, { useState } from "react";
import { useLibrary } from "../LibraryContext";
import { Book, Table, User, Transaction, Fine, BookReservation } from "../types";
import { 
  PlusCircle, Trash2, Library, Users, Armchair, ClipboardList, BookOpen, AlertCircle,
  Clock, DollarSign, Calendar, Search, Sparkles, Filter, ShieldCheck, FileCheck2, ScrollText, CheckCircle2
} from "lucide-react";

export const AdminDashboard: React.FC = () => {
  const {
    books, tables, users, transactions, fines, reservations, logout,
    addBook, removeBook, addTable, removeTable, deleteUser,
    getEffectiveBorrowLimit, hasOverdueBooks
  } = useLibrary();

  const [activeSubPanel, setActiveSubPanel] = useState<"BOOKS" | "TABLES" | "USERS" | "TXS_LOGS">("BOOKS");

  // Notifications
  const [success, setSuccess] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const triggerNotification = (res: { success: boolean; message: string }) => {
    if (res.success) {
      setSuccess(res.message);
      setError(null);
      setTimeout(() => setSuccess(null), 4000);
    } else {
      setError(res.message);
      setSuccess(null);
      setTimeout(() => setError(null), 4000);
    }
  };

  // --- BOOK FORM STATE ---
  const [bTitle, setBTitle] = useState("");
  const [bAuthor, setBAuthor] = useState("");
  const [bCategory, setBCategory] = useState("");
  const [bIsbn, setBIsbn] = useState("");
  const [bPublisher, setBPublisher] = useState("");
  const [bYear, setBYear] = useState<number>(2024);
  const [bCopies, setBCopies] = useState<number>(5);
  const [bookSearch, setBookSearch] = useState("");

  const handleAddBookSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bTitle || !bAuthor || !bCategory || !bIsbn || !bPublisher || !bYear || !bCopies) {
      triggerNotification({ success: false, message: "Please fill in all book fields before registry." });
      return;
    }
    const res = addBook({
      title: bTitle,
      author: bAuthor,
      category: bCategory,
      isbn: bIsbn,
      publisher: bPublisher,
      year: Number(bYear),
      copies: Number(bCopies)
    });
    triggerNotification(res);
    if (res.success) {
      setBTitle("");
      setBAuthor("");
      setBCategory("");
      setBIsbn("");
      setBPublisher("");
    }
  };

  // --- TABLE FORM STATE ---
  const [tLocation, setTLocation] = useState("");
  const [tCapacity, setTCapacity] = useState<number>(4);

  const handleAddTableSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!tLocation || !tCapacity) {
      triggerNotification({ success: false, message: "Location and seat capacity are required." });
      return;
    }
    const res = addTable(tLocation, Number(tCapacity));
    triggerNotification(res);
    if (res.success) {
      setTLocation("");
      setTCapacity(4);
    }
  };

  // --- USER FILTERS AND STATS ---
  const [userSearchText, setUserSearchText] = useState("");
  const [userRoleFilter, setUserRoleFilter] = useState<"ALL" | "STUDENT" | "FACULTY" | "GUEST" | "DELETED">("ALL");

  const filteredUsers = users.filter((u) => {
    const matchesSearch = u.name.toLowerCase().includes(userSearchText.toLowerCase()) || 
                          u.username.toLowerCase().includes(userSearchText.toLowerCase()) ||
                          u.cnic.includes(userSearchText);
    
    if (userRoleFilter === "ALL") return matchesSearch && !u.isDeleted;
    if (userRoleFilter === "DELETED") return matchesSearch && u.isDeleted;
    return matchesSearch && u.type === userRoleFilter && !u.isDeleted;
  });

  const activeUsersCount = users.filter((u) => !u.isDeleted).length;
  const activeTxCount = transactions.filter((t) => !t.returned).length;
  const activeResCount = reservations.filter((r) => r.active).length;
  const totalFineIncurred = fines.reduce((sum, f) => sum + f.finalAmount, 0);

  return (
    <div id="admin-dashboard-container" className="space-y-6">
      {/* Top Banner details */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 border border-slate-950 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shadow-sm">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="bg-amber-400 text-slate-950 font-bold text-[10px] tracking-wider uppercase font-mono px-2 py-0.5 rounded-full flex items-center gap-1">
              <ShieldCheck className="w-3 h-3" />
              Librarian Operator
            </span>
            <span className="text-slate-400 text-xs font-mono">Terminal Active</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight">Library Administration Controls</h1>
          <p className="text-slate-400 text-xs mt-0.5">Authorized staff desk for books, tables, reservations, and fine accounting ledgers.</p>
        </div>

        <button
          onClick={logout}
          className="bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700/60 px-4 py-2 text-xs font-semibold rounded-xl transition duration-150 cursor-pointer self-start md:self-auto"
        >
          Close Session
        </button>
      </div>

      {/* Admin metrics bento */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-100 rounded-2xl p-5 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center shrink-0">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <span className="text-slate-400 font-mono text-xs block">Active Patrons</span>
            <span className="text-2xl font-extrabold text-slate-800 font-sans mt-0.5 block">{activeUsersCount}</span>
          </div>
        </div>

        <div className="bg-white border border-slate-100 rounded-2xl p-5 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center shrink-0">
            <BookOpen className="w-6 h-6" />
          </div>
          <div>
            <span className="text-slate-400 font-mono text-xs block">Active Borrowings</span>
            <span className="text-2xl font-extrabold text-slate-800 mt-0.5 block">{activeTxCount}</span>
          </div>
        </div>

        <div className="bg-white border border-slate-100 rounded-2xl p-5 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 bg-violet-50 text-violet-600 rounded-xl flex items-center justify-center shrink-0">
            <Calendar className="w-6 h-6" />
          </div>
          <div>
            <span className="text-slate-400 font-mono text-xs block">Reserved Sessions</span>
            <span className="text-2xl font-extrabold text-slate-800 mt-0.5 block">{activeResCount}</span>
          </div>
        </div>

        <div className="bg-white border border-slate-100 rounded-2xl p-5 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 bg-amber-50 text-amber-600 rounded-xl flex items-center justify-center shrink-0">
            <DollarSign className="w-6 h-6" />
          </div>
          <div>
            <span className="text-slate-400 font-mono text-xs block">Fines Assessed</span>
            <span className="text-xl font-bold text-slate-800 font-mono mt-0.5 block">Rs. {totalFineIncurred.toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* Notifications widgets */}
      {success && (
        <div className="p-4 bg-emerald-50 border border-emerald-100/60 rounded-xl text-emerald-700 text-xs font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-4.5 h-4.5 text-emerald-500 shrink-0" />
          <span>{success}</span>
        </div>
      )}
      {error && (
        <div className="p-4 bg-rose-50 border border-rose-100/60 rounded-xl text-rose-700 text-xs font-semibold flex items-center gap-2">
          <AlertCircle className="w-4.5 h-4.5 text-rose-500 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Selector Panels Subtabs */}
      <div className="flex border-b border-slate-100 gap-1 overflow-x-auto pb-0.5 font-medium">
        <button
          onClick={() => setActiveSubPanel("BOOKS")}
          className={`px-4 py-2.5 text-sm rounded-t-xl transition-all flex items-center gap-2 shrink-0 cursor-pointer ${
            activeSubPanel === "BOOKS" ? "bg-slate-50 text-slate-900 border-t-2 border-indigo-600 font-bold" : "text-slate-400 hover:text-slate-600"
          }`}
        >
          <Library className="w-4.5 h-4.5" /> Book Inventory ({books.length})
        </button>
        <button
          onClick={() => setActiveSubPanel("TABLES")}
          className={`px-4 py-2.5 text-sm rounded-t-xl transition-all flex items-center gap-2 shrink-0 cursor-pointer ${
            activeSubPanel === "TABLES" ? "bg-slate-50 text-slate-900 border-t-2 border-indigo-600 font-bold" : "text-slate-400 hover:text-slate-600"
          }`}
        >
          <Armchair className="w-4.5 h-4.5" /> Table Bookings ({tables.length}/10)
        </button>
        <button
          onClick={() => setActiveSubPanel("USERS")}
          className={`px-4 py-2.5 text-sm rounded-t-xl transition-all flex items-center gap-2 shrink-0 cursor-pointer ${
            activeSubPanel === "USERS" ? "bg-slate-50 text-slate-900 border-t-2 border-indigo-600 font-bold" : "text-slate-400 hover:text-slate-600"
          }`}
        >
          <Users className="w-4.5 h-4.5" /> Reader Registry
        </button>
        <button
          onClick={() => setActiveSubPanel("TXS_LOGS")}
          className={`px-4 py-2.5 text-sm rounded-t-xl transition-all flex items-center gap-2 shrink-0 cursor-pointer ${
            activeSubPanel === "TXS_LOGS" ? "bg-slate-50 text-slate-900 border-t-2 border-indigo-600 font-bold" : "text-slate-400 hover:text-slate-600"
          }`}
        >
          <ClipboardList className="w-4.5 h-4.5" /> System Ledgers & Logs
        </button>
      </div>

      {/* PANELS IN DEPTH */}

      {/* 1. BOOK MANAGEMENT PANEL */}
      {activeSubPanel === "BOOKS" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Form to Add Book */}
          <div className="bg-white border border-slate-100 p-6 rounded-2xl shadow-xs self-start">
            <h3 className="text-base font-bold text-slate-800 flex items-center gap-1.5 mb-4">
              <PlusCircle className="w-5 h-5 text-indigo-500" />
              Register New Book
            </h3>
            <form onSubmit={handleAddBookSubmit} className="space-y-4">
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono block mb-1">Book Title</label>
                <input
                  type="text"
                  required
                  value={bTitle}
                  onChange={(e) => setBTitle(e.target.value)}
                  placeholder="e.g. Introduction to Algorithms"
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-100 rounded-xl text-slate-700 text-sm focus:outline-none focus:bg-white focus:border-indigo-500 font-medium"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono block mb-1">Author Name [Letters Only]</label>
                <input
                  type="text"
                  required
                  value={bAuthor}
                  onChange={(e) => setBAuthor(e.target.value)}
                  placeholder="e.g. Thomas H. Cormen"
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-100 rounded-xl text-slate-700 text-sm focus:outline-none focus:bg-white focus:border-indigo-500 font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono block mb-1">Category [Letters Only]</label>
                  <input
                    type="text"
                    required
                    value={bCategory}
                    onChange={(e) => setBCategory(e.target.value)}
                    placeholder="e.g. Computer Science"
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-100 rounded-xl text-slate-700 text-sm focus:outline-none focus:bg-white focus:border-indigo-500 font-medium"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono block mb-1">Publisher</label>
                  <input
                    type="text"
                    required
                    value={bPublisher}
                    onChange={(e) => setBPublisher(e.target.value)}
                    placeholder="e.g. MIT Press"
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-100 rounded-xl text-slate-700 text-sm focus:outline-none focus:bg-white focus:border-indigo-500 font-medium"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono block mb-1">ISBN Code</label>
                  <input
                    type="text"
                    required
                    value={bIsbn}
                    onChange={(e) => setBIsbn(e.target.value)}
                    placeholder="e.g. 978-0262046305"
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-100 rounded-xl text-slate-700 text-sm focus:outline-none focus:bg-white focus:border-indigo-500 font-medium"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono block mb-1">Pub. Year</label>
                  <input
                    type="number"
                    min="1000"
                    max="2100"
                    required
                    value={bYear}
                    onChange={(e) => setBYear(Number(e.target.value))}
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-100 rounded-xl text-slate-700 text-sm focus:outline-none focus:bg-white focus:border-indigo-500 font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono block mb-1">Available Copy Inventory</label>
                <input
                  type="number"
                  min="1"
                  max="1000"
                  required
                  value={bCopies}
                  onChange={(e) => setBCopies(Number(e.target.value))}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-100 rounded-xl text-slate-700 text-sm focus:outline-none focus:bg-white focus:border-indigo-500 font-medium"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-2 px-4 rounded-xl text-xs font-bold tracking-wide uppercase transition duration-150 cursor-pointer"
              >
                Add to Public Catalogue
              </button>
            </form>
          </div>

          {/* Book Catalog Search Grid */}
          <div className="lg:col-span-2 bg-white border border-slate-100 p-6 rounded-2xl shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
              <h3 className="font-bold text-slate-800 text-base">Active Book Inventories</h3>
              <div className="relative max-w-xs w-full">
                <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  value={bookSearch}
                  onChange={(e) => setBookSearch(e.target.value)}
                  placeholder="Search title, category or ISBN..."
                  className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-100 rounded-lg text-xs font-medium focus:outline-none focus:bg-white focus:border-indigo-500"
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-100 text-slate-400 font-mono font-semibold uppercase bg-slate-50/50">
                    <th className="py-2.5 px-3">ID</th>
                    <th className="py-2.5 px-3">Title / Author</th>
                    <th className="py-2.5 px-3">Category</th>
                    <th className="py-2.5 px-3">Copies Left</th>
                    <th className="py-2.5 px-3">Engagement Stats</th>
                    <th className="py-2.5 px-3 text-right">Remove</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {books.filter(b => 
                    b.title.toLowerCase().includes(bookSearch.toLowerCase()) || 
                    b.category.toLowerCase().includes(bookSearch.toLowerCase()) ||
                    b.isbn.includes(bookSearch)
                  ).map((b) => (
                    <tr key={b.id} className="hover:bg-slate-55/30 transition">
                      <td className="py-3 px-3 font-mono font-bold text-slate-500">#{b.id}</td>
                      <td className="py-3 px-3">
                        <span className="font-bold text-slate-800 block">{b.title}</span>
                        <span className="text-slate-400 text-[10px] font-medium">{b.author} • {b.publisher} ({b.year})</span>
                      </td>
                      <td className="py-3 px-3">
                        <span className="bg-slate-100 text-slate-600 px-2 py-0.5 rounded-md font-medium">{b.category}</span>
                      </td>
                      <td className="py-3 px-3 font-mono font-semibold">
                        <span className={b.copies === 0 ? "text-rose-500" : "text-slate-700"}>
                          {b.copies}
                        </span>
                      </td>
                      <td className="py-3 px-3">
                        <div className="grid grid-cols-3 gap-2 font-mono text-[10px] text-slate-500 bg-slate-50 p-1.5 rounded-lg border border-slate-100">
                          <div>Read: <b className="text-slate-800">{b.read_onsite_count}</b></div>
                          <div>Down: <b className="text-slate-800">{b.download_count}</b></div>
                          <div>Bor: <b className="text-slate-800">{b.times_borrowed}</b></div>
                        </div>
                      </td>
                      <td className="py-3 px-3 text-right">
                        <button
                          onClick={() => {
                            if (confirm(`Exclude book "${b.title}"?`)) {
                              const res = removeBook(b.id);
                              triggerNotification(res);
                            }
                          }}
                          className="bg-rose-50 hover:bg-rose-100 text-rose-600 p-2 rounded-lg transition shrink-0 cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 2. TABLE MANAGEMENT PANEL */}
      {activeSubPanel === "TABLES" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Add Study Table Form */}
          <div className="bg-white border border-slate-100 p-6 rounded-2xl shadow-xs self-start">
            <h3 className="text-base font-bold text-slate-800 flex items-center gap-1.5 mb-4">
              <PlusCircle className="w-5 h-5 text-indigo-500" />
              Configure Study Table
            </h3>
            <form onSubmit={handleAddTableSubmit} className="space-y-4">
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono block mb-1">Study Room Location</label>
                <input
                  type="text"
                  required
                  value={tLocation}
                  onChange={(e) => setTLocation(e.target.value)}
                  placeholder="e.g. Silent Zone West Window 1"
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-100 rounded-xl text-slate-700 text-sm focus:outline-none focus:bg-white focus:border-indigo-500 font-medium"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono block mb-1">Seat Capacity limit</label>
                <input
                  type="number"
                  min="1"
                  max="100"
                  required
                  value={tCapacity}
                  onChange={(e) => setTCapacity(Number(e.target.value))}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-100 rounded-xl text-slate-700 text-sm focus:outline-none focus:bg-white focus:border-indigo-500 font-medium"
                />
              </div>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-100/50 text-[10px] leading-relaxed text-slate-400/80 mb-2 font-mono">
                Tables support automatic conflict checking. Max capacity limits help allocate readers. Maximum 10 tables total.
              </div>

              <button
                type="submit"
                className="w-full bg-slate-850 hover:bg-slate-900 text-white py-2 px-4 rounded-xl text-xs font-bold tracking-wide uppercase transition duration-150 cursor-pointer"
              >
                Register Table Hall
              </button>
            </form>
          </div>

          {/* Active Tables Grid */}
          <div className="lg:col-span-2 bg-white border border-slate-100 p-6 rounded-2xl shadow-xs">
            <h3 className="font-bold text-slate-800 text-base mb-4">Active Reading Hall Tables</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {tables.map((t) => {
                const activeBookings = reservations.filter(r => r.tableid === t.id && r.active);
                
                return (
                  <div key={t.id} className="border border-slate-100 hover:border-indigo-200 rounded-xl p-4 transition-all duration-200">
                    <div className="flex justify-between items-start mb-2">
                      <span className="text-xs font-mono font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full">
                        Table #{t.id}
                      </span>
                      <button
                        onClick={() => {
                          if (confirm(`Remove table #${t.id}?`)) {
                            const res = removeTable(t.id);
                            triggerNotification(res);
                          }
                        }}
                        className="text-rose-400 hover:text-rose-600 transition shrink-0 cursor-pointer"
                        title="Delete desk"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    <h4 className="font-bold text-slate-800 text-sm">{t.location}</h4>
                    <p className="text-slate-400 text-xs font-mono mt-0.5">Capacity limit: {t.capacity} seats</p>

                    <div className="mt-3 pt-3 border-t border-slate-50 flex items-center justify-between text-[11px] font-mono">
                      <span className="text-slate-400">Total bookings:</span>
                      <span className="text-slate-800 font-bold">{activeBookings.length} Active</span>
                    </div>
                  </div>
                );
              })}
              {tables.length === 0 && (
                <div className="col-span-2 text-center py-10 text-slate-400 font-mono text-xs">
                  No tables configured. Please add study desks.
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 3. USER REGISTRY PANEL */}
      {activeSubPanel === "USERS" && (
        <div className="bg-white border border-slate-100 p-6 rounded-2xl shadow-xs">
          {/* Filters controls Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-5 mb-5">
            <div>
              <h3 className="font-bold text-slate-800 text-base">Registered Reader Directory</h3>
              <p className="text-slate-500 text-xs mt-0.5">Authorized panel to lookup students, faculties, or guest records.</p>
            </div>

            <div className="flex flex-col sm:flex-row gap-2 shrink-0 max-w-md w-full md:w-auto">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  value={userSearchText}
                  onChange={(e) => setUserSearchText(e.target.value)}
                  placeholder="Find name, username, CNIC..."
                  className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-100 rounded-xl text-xs font-medium focus:outline-none"
                />
              </div>

              {/* Status Filters buttons list */}
              <div className="flex gap-1.5 bg-slate-50 border border-slate-100 p-1 rounded-xl">
                {(["ALL", "STUDENT", "FACULTY", "GUEST", "DELETED"] as ("ALL" | "STUDENT" | "FACULTY" | "GUEST" | "DELETED")[]).map((role) => (
                  <button
                    key={role}
                    onClick={() => setUserRoleFilter(role)}
                    className={`px-2 py-1 text-[10px] font-bold tracking-wide uppercase rounded-lg transition duration-150 cursor-pointer ${
                      userRoleFilter === role
                        ? "bg-white text-slate-800 shadow-xs border border-slate-100/50"
                        : "text-slate-400 hover:text-slate-700"
                    }`}
                  >
                    {role}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Cards dynamic mapping grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {filteredUsers.map((u) => {
              const maxL = getEffectiveBorrowLimit(u);
              const totalBorrowed = u.borrowedIds?.length || 0;
              
              return (
                <div key={u.id} className="bg-white border border-slate-100 hover:border-indigo-100 rounded-2xl p-5 shadow-xs transition duration-200">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <span className={`text-[9px] font-bold tracking-wider uppercase font-mono px-2 py-0.5 rounded-full ${
                        u.type === "STUDENT" ? "bg-indigo-50 text-indigo-600" :
                        u.type === "FACULTY" ? "bg-emerald-50 text-emerald-600" :
                        "bg-violet-50 text-violet-600"
                      }`}>
                        {u.type}
                      </span>
                      {u.membership?.active && (
                        <span className="shadow-amber-100 bg-amber-50 text-amber-700 text-[9px] font-bold tracking-wider uppercase font-mono ml-1.5 px-2 py-0.5 rounded-full border border-amber-200/50">
                          MEMBER
                        </span>
                      )}
                    </div>

                    <button
                      onClick={() => {
                        if (confirm(`Soft-Delete user "${u.name}" (ID ${u.id})? This marks profile as deleted without purging transactions.`)) {
                          const res = deleteUser(u.id);
                          triggerNotification(res);
                        }
                      }}
                      className="text-rose-400 hover:text-rose-600 transition shrink-0 p-1 rounded hover:bg-rose-50 cursor-pointer"
                      title="Perform soft deletion"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <h4 className="font-bold text-slate-800 text-sm flex items-center gap-1.5">
                    {u.name}
                    <span className="text-slate-400 text-xs font-mono font-medium">(ID #{u.id})</span>
                  </h4>
                  <p className="text-slate-400 text-xs font-medium mt-0.5">{u.email}</p>

                  {/* Type specific specs details */}
                  <div className="bg-slate-50 rounded-xl p-3 border border-slate-100/60 text-xs mt-3.5 space-y-2">
                    <div className="flex justify-between font-mono text-slate-500">
                      <span>Username:</span>
                      <span className="font-bold text-slate-700">{u.username}</span>
                    </div>
                    <div className="flex justify-between font-mono text-slate-500">
                      <span>CNIC Code:</span>
                      <span className="text-slate-700 font-medium">{u.cnic}</span>
                    </div>
                    <div className="flex justify-between font-mono text-slate-500">
                      <span>Library Balance:</span>
                      <span className={`font-bold ${u.balance < 0 ? "text-rose-500" : "text-emerald-600"}`}>
                        Rs. {u.balance} {u.balance <= -500 ? "⚠️" : ""}
                      </span>
                    </div>

                    {u.type === "STUDENT" && u.seatno && (
                      <div className="flex justify-between font-mono text-slate-500 border-t border-slate-103/50 pt-1.5">
                        <span>Seat / Major:</span>
                        <span className="text-slate-700 truncate max-w-[120px]">{u.seatno} • {u.major}</span>
                      </div>
                    )}
                    {u.type === "FACULTY" && u.department && (
                      <div className="flex justify-between font-mono text-slate-500 border-t border-slate-103/50 pt-1.5">
                        <span>Dept / Post:</span>
                        <span className="text-slate-700 truncate max-w-[120px]">{u.department} • {u.designation}</span>
                      </div>
                    )}
                    {u.type === "GUEST" && u.purpose && (
                      <div className="flex justify-between font-mono text-slate-500 border-t border-slate-103/50 pt-1.5">
                        <span>Purpose:</span>
                        <span className="text-slate-700 truncate max-w-[120px]" title={u.purpose}>{u.purpose}</span>
                      </div>
                    )}
                  </div>

                  <div className="mt-4 pt-3.5 border-t border-slate-50 grid grid-cols-2 text-center text-xs text-slate-400">
                    <div className="border-r border-slate-50">
                      <span className="block font-mono font-bold text-slate-700">{totalBorrowed} / {maxL}</span>
                      <span className="text-[10px] uppercase font-bold tracking-wider font-mono">Borrows</span>
                    </div>
                    <div>
                      <span className="block font-mono font-bold text-indigo-600">Rs. {u.total_fines_paid}</span>
                      <span className="text-[10px] uppercase font-bold tracking-wider font-mono">Fines Paid</span>
                    </div>
                  </div>
                </div>
              );
            })}

            {filteredUsers.length === 0 && (
              <div className="col-span-full text-center py-10 text-slate-400 text-xs font-mono">
                No matching dynamic reader catalog records found.
              </div>
            )}
          </div>
        </div>
      )}

      {/* 4. TRANSACTION LOGS LEDGER */}
      {activeSubPanel === "TXS_LOGS" && (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
          {/* Active Borrow logs ledgers */}
          <div className="bg-white border border-slate-100 p-6 rounded-2xl shadow-xs">
            <h3 className="font-bold text-slate-800 text-sm uppercase tracking-wider font-mono text-slate-500 mb-4 flex items-center gap-1">
              <ScrollText className="w-4.5 h-4.5 text-indigo-500" />
              Active Borrow Check-Outs ({transactions.filter(t => !t.returned).length})
            </h3>

            <div className="divide-y divide-slate-100 max-h-[400px] overflow-y-auto pr-1">
              {transactions.filter(t => !t.returned).map((t) => {
                const book = books.find(b => b.id === t.bid);
                const user = users.find(u => u.id === t.uid);
                const isLate = new Date(t.due_time) < new Date();
                
                return (
                  <div key={t.tid} className="py-3 flex justify-between items-start gap-3">
                    <div className="min-w-0">
                      <span className="text-slate-400 text-[10px] font-mono leading-none block mb-1">TXID #{t.tid}</span>
                      <h4 className="font-bold text-slate-800 text-xs truncate">{book?.title || "Unknown Book"}</h4>
                      <p className="text-slate-400 text-[10px] leading-tight mt-0.5 truncate">
                        Borrowed by: <span className="text-slate-700 font-bold">{user?.name || "Deleted User"}</span>
                      </p>
                    </div>

                    <div className="shrink-0 text-right text-[10px] font-mono">
                      <span className={`px-2 py-0.5 rounded font-bold uppercase ${isLate ? "bg-rose-50 text-rose-600" : "bg-emerald-50 text-emerald-600"}`}>
                        {isLate ? "Overdue" : "On Checked-Out"}
                      </span>
                      <p className="text-slate-400 text-[9px] mt-1.5">Due: {new Date(t.due_time).toLocaleTimeString()}</p>
                    </div>
                  </div>
                );
              })}
              {transactions.filter(t => !t.returned).length === 0 && (
                <div className="text-center py-10 text-slate-400 text-xs font-mono">
                  No active borrows currently.
                </div>
              )}
            </div>
          </div>

          {/* Fine Assessed Log Record Ledgers */}
          <div className="bg-white border border-slate-100 p-6 rounded-2xl shadow-xs">
            <h3 className="font-bold text-slate-800 text-sm uppercase tracking-wider font-mono text-slate-500 mb-4 flex items-center gap-1">
              <DollarSign className="w-4.5 h-4.5 text-amber-500" />
              Fine Settlement Ledger Entries ({fines.length})
            </h3>

            <div className="divide-y divide-slate-100 max-h-[400px] overflow-y-auto pr-1">
              {fines.map((f, index) => {
                const user = users.find(u => u.id === f.user_id);
                const book = books.find(b => b.id === f.book_id);
                
                return (
                  <div key={index} className="py-3 flex justify-between items-center gap-3">
                    <div className="min-w-0">
                      <span className="text-slate-400 text-[9px] font-mono block">Fine entry index #{index + 1}</span>
                      <h4 className="font-bold text-slate-700 text-xs truncate">Reader: {user?.name || "Deleted User"}</h4>
                      <p className="text-slate-400 text-[10px] mt-0.5 truncate leading-none">
                        For library copy: <span className="text-slate-600 font-mono font-medium">{book?.title || "Book"}</span>
                      </p>
                    </div>

                    <div className="shrink-0 text-right">
                      <span className="font-mono font-bold text-slate-800 text-xs block">
                        Rs. {f.finalAmount}
                      </span>
                      <span className="text-[9px] text-slate-400 font-mono">
                        {f.minuteslate} mins late {f.discountApplied ? "(15% member disc.)" : "(un-discounted)"}
                      </span>
                    </div>
                  </div>
                );
              })}
              {fines.length === 0 && (
                <div className="text-center py-10 text-slate-400 text-xs font-mono">
                  No fine entries logged. Clean record!
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
