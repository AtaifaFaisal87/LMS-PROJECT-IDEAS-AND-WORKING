import React, { createContext, useContext, useState, useEffect } from "react";
import { Book, Table, User, Transaction, Fine, BookReservation, UserType } from "./types";
import { MOCK_BOOKS, MOCK_TABLES, MOCK_USERS } from "./mockData";

interface LibraryContextType {
  books: Book[];
  tables: Table[];
  users: User[];
  transactions: Transaction[];
  fines: Fine[];
  reservations: BookReservation[];
  currentUser: User | null;
  adminLoggedIn: boolean;
  
  // Auth
  loginAsUser: (username: string, password: string) => { success: boolean; message: string };
  loginAsAdmin: (password: string) => { success: boolean; message: string };
  logout: () => void;
  registerUser: (newUser: Omit<User, "id" | "borrowedIds" | "daily_borrows" | "last_borrow_date" | "total_fines_paid">) => { success: boolean; message: string };
  
  // User Profile
  updateUserProfile: (updated: Partial<User>) => void;
  addFunds: (amount: number) => void;
  activateMembership: () => void;
  cancelMembership: () => void;
  
  // Book Actions
  borrowBook: (bookId: number, durationMinutes: number) => { success: boolean; message: string };
  returnBook: (bookId: number, simulateLateMinutes: number) => { success: boolean; message: string; fineGened?: Fine };
  readOnSite: (bookId: number) => void;
  downloadBook: (bookId: number) => void;
  
  // Table / Book Reservations
  reserveTableManual: (tableId: number, date: string, start: string, end: string) => { success: boolean; message: string };
  reserveTableAuto: (date: string, start: string, end: string) => { success: boolean; message: string; tableId?: number };
  reserveBookOnsite: (bookId: number, date: string, start: string, end: string) => { success: boolean; message: string };
  cancelReservation: (resId: number) => void;
  
  // Admin Operations
  addBook: (book: Omit<Book, "id" | "download_count" | "read_onsite_count" | "times_borrowed">) => { success: boolean; message: string };
  removeBook: (bookId: number) => { success: boolean; message: string };
  addTable: (location: string, capacity: number) => { success: boolean; message: string };
  removeTable: (tableId: number) => { success: boolean; message: string };
  deleteUser: (userId: number) => { success: boolean; message: string };
  
  // Helpers
  getEffectiveBorrowLimit: (user: User) => number;
  hasOverdueBooks: (user: User) => boolean;
  getOverdueBooksCount: (user: User) => number;

  // Theming
  currentTheme: string;
  setTheme: (theme: string) => void;

  // Data Clean Slate & Loaders
  clearDatabase: () => void;
  loadMockData: () => void;
}

const LibraryContext = createContext<LibraryContextType | undefined>(undefined);

const STORAGE_KEYS = {
  BOOKS: "athena_books",
  TABLES: "athena_tables",
  USERS: "athena_users",
  TXS: "athena_transactions",
  FINES: "athena_fines",
  RESERVATIONS: "athena_reservations",
  CURRENT_USER: "athena_current_user",
  ADMIN_LOGGED_IN: "athena_admin_logged_in",
  THEME: "redora_theme"
};

export const LibraryProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [books, setBooks] = useState<Book[]>([]);
  const [tables, setTables] = useState<Table[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [fines, setFines] = useState<Fine[]>([]);
  const [reservations, setBookReservations] = useState<BookReservation[]>([]);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [adminLoggedIn, setAdminLoggedIn] = useState<boolean>(false);
  const [currentTheme, setCurrentThemeState] = useState<string>("redora");

  // Load initial data from localStorage or fallback to mock
  useEffect(() => {
    const localBooks = localStorage.getItem(STORAGE_KEYS.BOOKS);
    const localTables = localStorage.getItem(STORAGE_KEYS.TABLES);
    const localUsers = localStorage.getItem(STORAGE_KEYS.USERS);
    const localTxs = localStorage.getItem(STORAGE_KEYS.TXS);
    const localFines = localStorage.getItem(STORAGE_KEYS.FINES);
    const localRes = localStorage.getItem(STORAGE_KEYS.RESERVATIONS);
    const localUser = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    const localAdmin = localStorage.getItem(STORAGE_KEYS.ADMIN_LOGGED_IN);
    const localTheme = localStorage.getItem(STORAGE_KEYS.THEME) || "redora";

    // Set to empty arrays by default so that the database starts clean, and the user enters everything!
    setBooks(localBooks ? JSON.parse(localBooks) : []);
    setTables(localTables ? JSON.parse(localTables) : []);
    setUsers(localUsers ? JSON.parse(localUsers) : []);
    setTransactions(localTxs ? JSON.parse(localTxs) : []);
    setFines(localFines ? JSON.parse(localFines) : []);
    setBookReservations(localRes ? JSON.parse(localRes) : []);
    setCurrentUser(localUser ? JSON.parse(localUser) : null);
    setAdminLoggedIn(localAdmin ? JSON.parse(localAdmin) === "true" : false);
    setCurrentThemeState(localTheme);
  }, []);

  // Update body theme class when currentTheme changes
  useEffect(() => {
    document.body.className = "theme-" + currentTheme;
  }, [currentTheme]);

  const setTheme = (theme: string) => {
    localStorage.setItem(STORAGE_KEYS.THEME, theme);
    setCurrentThemeState(theme);
  };

  const setReservations = (res: BookReservation[]) => {
    setBookReservations(res);
  };

  // Clear Database completely
  const clearDatabase = () => {
    localStorage.removeItem(STORAGE_KEYS.BOOKS);
    localStorage.removeItem(STORAGE_KEYS.TABLES);
    localStorage.removeItem(STORAGE_KEYS.USERS);
    localStorage.removeItem(STORAGE_KEYS.TXS);
    localStorage.removeItem(STORAGE_KEYS.FINES);
    localStorage.removeItem(STORAGE_KEYS.RESERVATIONS);
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    localStorage.removeItem(STORAGE_KEYS.ADMIN_LOGGED_IN);

    setBooks([]);
    setTables([]);
    setUsers([]);
    setTransactions([]);
    setFines([]);
    setBookReservations([]);
    setCurrentUser(null);
    setAdminLoggedIn(false);
  };

  // Load standard seed mock data
  const loadMockData = () => {
    saveState(STORAGE_KEYS.BOOKS, MOCK_BOOKS, setBooks);
    saveState(STORAGE_KEYS.TABLES, MOCK_TABLES, setTables);
    saveState(STORAGE_KEYS.USERS, MOCK_USERS, setUsers);
    saveState(STORAGE_KEYS.TXS, [], setTransactions);
    saveState(STORAGE_KEYS.FINES, [], setFines);
    saveState(STORAGE_KEYS.RESERVATIONS, [], setBookReservations);
    setCurrentUser(null);
    setAdminLoggedIn(false);
  };

  // Save changes helper
  const saveState = (key: string, data: any, stateSetter: Function) => {
    localStorage.setItem(key, JSON.stringify(data));
    stateSetter(data);
  };

  // Custom sync for active user session profile changes
  const updateActiveUserSession = (userId: number, allUsers: User[]) => {
    const updatedUser = allUsers.find(u => u.id === userId);
    if (updatedUser) {
      saveState(STORAGE_KEYS.CURRENT_USER, updatedUser, setCurrentUser);
    }
  };

  // POLICIES AND LIMITS
  const getEffectiveBorrowLimit = (user: User): number => {
    let base = 3;
    if (user.type === "FACULTY") base = 5;
    if (user.type === "GUEST") base = 1;

    // Membership boosts: Student +2, Faculty +2, Guest +1
    if (user.membership?.active) {
      if (user.type === "GUEST") return base + 1;
      return base + 2;
    }
    return base;
  };

  const getFineRate = (type: UserType): number => {
    if (type === "STUDENT") return 10;
    if (type === "FACULTY") return 15;
    return 20; // GUEST
  };

  const hasOverdueBooks = (user: User): boolean => {
    const now = new Date();
    return transactions.some(t => 
      t.uid === user.id && 
      !t.returned && 
      new Date(t.due_time) < now
    );
  };

  const getOverdueBooksCount = (user: User): number => {
    const now = new Date();
    return transactions.filter(t => 
      t.uid === user.id && 
      !t.returned && 
      new Date(t.due_time) < now
    ).length;
  };

  const getTodayDateString = (): string => {
    const t = new Date();
    const day = String(t.getDate()).padStart(2, "0");
    const month = String(t.getMonth() + 1).padStart(2, "0");
    const year = t.getFullYear();
    return `${day}/${month}/${year}`;
  };

  // AUTHENTICATION
  const loginAsUser = (username: string, password: string) => {
    const foundUser = users.find(u => u.username.toLowerCase() === username.toLowerCase() && u.password === password);
    if (!foundUser) {
      return { success: false, message: "Invalid username or password!" };
    }
    if (foundUser.isDeleted) {
      return { success: false, message: "This account has been deleted. Please contact administration." };
    }
    
    // Check if membership is expired and update if needed
    let updatedUser = { ...foundUser };
    if (foundUser.membership?.active) {
      const now = new Date();
      if (new Date(foundUser.membership.expiryTime) < now) {
        updatedUser.membership = { ...foundUser.membership, active: false };
        const updatedUsersList = users.map(u => u.id === foundUser.id ? updatedUser : u);
        saveState(STORAGE_KEYS.USERS, updatedUsersList, setUsers);
      }
    }

    setAdminLoggedIn(false);
    localStorage.removeItem(STORAGE_KEYS.ADMIN_LOGGED_IN);
    saveState(STORAGE_KEYS.CURRENT_USER, updatedUser, setCurrentUser);
    return { success: true, message: `Welcome back, ${updatedUser.name}!` };
  };

  const loginAsAdmin = (password: string) => {
    if (password === "123") {
      setCurrentUser(null);
      localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
      setAdminLoggedIn(true);
      localStorage.setItem(STORAGE_KEYS.ADMIN_LOGGED_IN, "true");
      return { success: true, message: "Librarian administration login successful!" };
    }
    return { success: false, message: "Invalid administrator password!" };
  };

  const logout = () => {
    setCurrentUser(null);
    setAdminLoggedIn(false);
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    localStorage.removeItem(STORAGE_KEYS.ADMIN_LOGGED_IN);
  };

  const registerUser = (newUserFields: Omit<User, "id" | "borrowedIds" | "daily_borrows" | "last_borrow_date" | "total_fines_paid">) => {
    // Check duplicates
    const cnicExists = users.some(u => !u.isDeleted && u.cnic === newUserFields.cnic);
    const emailExists = users.some(u => !u.isDeleted && u.email.toLowerCase() === newUserFields.email.toLowerCase());
    const usernameExists = users.some(u => !u.isDeleted && u.username.toLowerCase() === newUserFields.username.toLowerCase());
    const phoneExists = users.some(u => !u.isDeleted && u.phone === newUserFields.phone);

    if (cnicExists) return { success: false, message: "Registration failed! A user with this CNIC already exists." };
    if (emailExists) return { success: false, message: "Registration failed! A user with this email already exists." };
    if (usernameExists) return { success: false, message: "Registration failed! This username is already taken." };
    if (phoneExists) return { success: false, message: "Registration failed! This phone number is already registered." };

    const nextId = users.length > 0 ? Math.max(...users.map(u => u.id)) + 1 : 1;
    const user: User = {
      ...newUserFields,
      id: nextId,
      borrowedIds: [],
      daily_borrows: 0,
      last_borrow_date: "",
      total_fines_paid: 0,
      isDeleted: false
    };

    const updated = [...users, user];
    saveState(STORAGE_KEYS.USERS, updated, setUsers);
    return { success: true, message: "Registration successful! You can now log in." };
  };

  // PROFILE MANAGEMENT
  const updateUserProfile = (updatedFields: Partial<User>) => {
    if (!currentUser) return;
    
    // Check username duplication
    if (updatedFields.username) {
      const duplicate = users.some(u => u.id !== currentUser.id && !u.isDeleted && u.username.toLowerCase() === updatedFields.username?.toLowerCase());
      if (duplicate) {
        alert("Username already exists!");
        return;
      }
    }

    const updatedUsers = users.map(u => {
      if (u.id === currentUser.id) {
        return { ...u, ...updatedFields };
      }
      return u;
    });

    saveState(STORAGE_KEYS.USERS, updatedUsers, setUsers);
    updateActiveUserSession(currentUser.id, updatedUsers);
  };

  const addFunds = (amount: number) => {
    if (!currentUser) return;
    const updatedUsers = users.map(u => {
      if (u.id === currentUser.id) {
        return { ...u, balance: u.balance + amount };
      }
      return u;
    });
    saveState(STORAGE_KEYS.USERS, updatedUsers, setUsers);
    updateActiveUserSession(currentUser.id, updatedUsers);
  };

  const activateMembership = () => {
    if (!currentUser) return;
    const now = new Date();
    const expiry = new Date();
    expiry.setFullYear(now.getFullYear() + 1);

    const updatedUsers = users.map(u => {
      if (u.id === currentUser.id) {
        return {
          ...u,
          membership: {
            active: true,
            activationTime: now.toISOString(),
            expiryTime: expiry.toISOString(),
            durationDays: 365
          }
        };
      }
      return u;
    });

    saveState(STORAGE_KEYS.USERS, updatedUsers, setUsers);
    updateActiveUserSession(currentUser.id, updatedUsers);
  };

  const cancelMembership = () => {
    if (!currentUser) return;
    const updatedUsers = users.map(u => {
      if (u.id === currentUser.id) {
        return {
          ...u,
          membership: undefined
        };
      }
      return u;
    });

    saveState(STORAGE_KEYS.USERS, updatedUsers, setUsers);
    updateActiveUserSession(currentUser.id, updatedUsers);
  };

  // BOOK ACTIONS
  const borrowBook = (bookId: number, durationMinutes: number) => {
    if (!currentUser) return { success: false, message: "Please log in first!" };
    
    // 1. Overdue Block helper
    if (hasOverdueBooks(currentUser)) {
      return { success: false, message: "Borrow blocked! You have overdue books. Please return them first." };
    }

    // 2. Unpaid Fine Check (exceeding Rs. 500)
    if (currentUser.balance <= -500.0) {
      return { success: false, message: "Borrow blocked! Your outstanding dynamic unpaid debt exceeds Rs. 500. Please clear your balance." };
    }

    // 3. Daily Borrow Limit tracking
    const today = getTodayDateString();
    let dailyCount = currentUser.daily_borrows;
    if (currentUser.last_borrow_date !== today) {
      dailyCount = 0;
    }

    const maxConcurrent = getEffectiveBorrowLimit(currentUser);
    if (currentUser.borrowedIds.length >= maxConcurrent) {
      return { success: false, message: `Borrow limit reached! You can only borrow up to ${maxConcurrent} books at once.` };
    }

    if (dailyCount >= maxConcurrent) {
      return { success: false, message: `Daily borrow limit reached! You can borrow at most ${maxConcurrent} books in one day.` };
    }

    // Check available book
    const book = books.find(b => b.id === bookId);
    if (!book) return { success: false, message: "Book not found!" };
    if (book.copies <= 0) return { success: false, message: "No available copies left for this book." };

    // Process borrow
    const now = new Date();
    const due = new Date(now.getTime() + durationMinutes * 60 * 1000);

    const nextTxId = transactions.length > 0 ? Math.max(...transactions.map(t => t.tid)) + 1 : 1;
    const newTx: Transaction = {
      tid: nextTxId,
      uid: currentUser.id,
      bid: bookId,
      borrow_time: now.toISOString(),
      due_time: due.toISOString(),
      returned: false
    };

    // Update Book copies & stats
    const updatedBooks = books.map(b => {
      if (b.id === bookId) {
        return { ...b, copies: b.copies - 1, times_borrowed: b.times_borrowed + 1 };
      }
      return b;
    });

    // Update User borrowed ids & daily stats
    const updatedUsers = users.map(u => {
      if (u.id === currentUser.id) {
        return {
          ...u,
          borrowedIds: [...u.borrowedIds, bookId],
          daily_borrows: dailyCount + 1,
          last_borrow_date: today
        };
      }
      return u;
    });

    saveState(STORAGE_KEYS.BOOKS, updatedBooks, setBooks);
    saveState(STORAGE_KEYS.USERS, updatedUsers, setUsers);
    saveState(STORAGE_KEYS.TXS, [...transactions, newTx], setTransactions);
    updateActiveUserSession(currentUser.id, updatedUsers);

    return { 
      success: true, 
      message: `Successfully borrowed "${book.title}"! Return expected by ${due.toLocaleTimeString()} today.` 
    };
  };

  const returnBook = (bookId: number, simulateLateMinutes: number) => {
    if (!currentUser) return { success: false, message: "Please log in first!" };

    // Find active transaction
    const activeTxIndex = transactions.findIndex(t => t.uid === currentUser.id && t.bid === bookId && !t.returned);
    if (activeTxIndex === -1) {
      return { success: false, message: "You don't have an active borrow for this book!" };
    }

    const targetTx = transactions[activeTxIndex];
    const now = new Date();
    
    // Simulate return times and dates
    let simulatedReturnTime = new Date();
    let isLate = simulateLateMinutes > 0;
    
    if (isLate) {
      // Force return time to be due_time + late margin
      const due = new Date(targetTx.due_time);
      simulatedReturnTime = new Date(due.getTime() + simulateLateMinutes * 60 * 1000);
    }

    const updatedTx: Transaction = {
      ...targetTx,
      returned: true,
      return_time: simulatedReturnTime.toISOString(),
      return_date: simulatedReturnTime.toLocaleDateString() + " " + simulatedReturnTime.toLocaleTimeString()
    };

    // Update transactions
    const updatedTxs = transactions.map((t, idx) => idx === activeTxIndex ? updatedTx : t);

    // Update book copies
    const updatedBooks = books.map(b => {
      if (b.id === bookId) {
        return { ...b, copies: b.copies + 1 };
      }
      return b;
    });

    // Fines calculation
    let generatedFine: Fine | undefined = undefined;
    let finalFineAmount = 0;
    
    if (isLate) {
      const rate = getFineRate(currentUser.type);
      const original = rate * simulateLateMinutes;
      const discount = currentUser.membership?.active || false;
      finalFineAmount = discount ? original * 0.85 : original;

      generatedFine = {
        user_id: currentUser.id,
        book_id: bookId,
        minuteslate: simulateLateMinutes,
        rate,
        originalAmount: original,
        finalAmount: finalFineAmount,
        discountApplied: discount,
        paidAt: now.toISOString()
      };
    }

    // Update User Balance (auto-deduct dynamic fines)
    const updatedUsers = users.map(u => {
      if (u.id === currentUser.id) {
        return {
          ...u,
          borrowedIds: u.borrowedIds.filter(id => id !== bookId),
          balance: u.balance - finalFineAmount,
          total_fines_paid: u.total_fines_paid + finalFineAmount
        };
      }
      return u;
    });

    // Write-through
    saveState(STORAGE_KEYS.BOOKS, updatedBooks, setBooks);
    saveState(STORAGE_KEYS.USERS, updatedUsers, setUsers);
    saveState(STORAGE_KEYS.TXS, updatedTxs, setTransactions);
    if (generatedFine) {
      saveState(STORAGE_KEYS.FINES, [...fines, generatedFine], setFines);
    }
    updateActiveUserSession(currentUser.id, updatedUsers);

    const bTitle = books.find(b => b.id === bookId)?.title || "Book";
    let statusMessage = `Returned "${bTitle}" successfully!`;
    if (isLate && generatedFine) {
      statusMessage += ` Overdue by ${simulateLateMinutes} minutes. Fine of Rs. ${finalFineAmount} was automatically deducted from your library balance.`;
    }

    return { 
      success: true, 
      message: statusMessage,
      fineGened: generatedFine 
    };
  };

  const readOnSite = (bookId: number) => {
    const updatedBooks = books.map(b => {
      if (b.id === bookId) {
        return { ...b, read_onsite_count: b.read_onsite_count + 1 };
      }
      return b;
    });
    saveState(STORAGE_KEYS.BOOKS, updatedBooks, setBooks);
  };

  const downloadBook = (bookId: number) => {
    const updatedBooks = books.map(b => {
      if (b.id === bookId) {
        return { ...b, download_count: b.download_count + 1 };
      }
      return b;
    });
    saveState(STORAGE_KEYS.BOOKS, updatedBooks, setBooks);
  };

  // RESERVATIONS
  const overlap = (s1: string, e1: string, s2: string, e2: string): boolean => {
    return !(e1 <= s2 || e2 <= s1);
  };

  const checkTableConflict = (tableId: number, date: string, start: string, end: string): boolean => {
    return reservations.some(r => 
      r.active && 
      r.tableid === tableId && 
      r.date === date && 
      overlap(r.startTime, r.endTime, start, end)
    );
  };

  const reserveTableManual = (tableId: number, date: string, start: string, end: string) => {
    if (!currentUser) return { success: false, message: "Please log in first!" };

    // Check conflict
    const conflict = checkTableConflict(tableId, date, start, end);
    if (conflict) {
      return { success: false, message: "Conflict detected! Table is already booked for this slot." };
    }

    const nextId = reservations.length > 0 ? Math.max(...reservations.map(r => r.reservationid)) + 1 : 1;
    const res: BookReservation = {
      reservationid: nextId,
      userid: currentUser.id,
      bookid: 0,
      tableid: tableId,
      date,
      startTime: start,
      endTime: end,
      active: true
    };

    saveState(STORAGE_KEYS.RESERVATIONS, [...reservations, res], setReservations);
    return { success: true, message: `Successfully reserved Study Table #${tableId} for ${date}!` };
  };

  const reserveTableAuto = (date: string, start: string, end: string) => {
    if (!currentUser) return { success: false, message: "Please log in first!" };
    if (tables.length === 0) return { success: false, message: "No study tables are currently registered!" };

    // Find first table without conflict
    const availableTable = tables.find(t => !checkTableConflict(t.id, date, start, end));
    if (!availableTable) {
      return { success: false, message: "No tables available for your selected study window!" };
    }

    const nextId = reservations.length > 0 ? Math.max(...reservations.map(r => r.reservationid)) + 1 : 1;
    const res: BookReservation = {
      reservationid: nextId,
      userid: currentUser.id,
      bookid: 0,
      tableid: availableTable.id,
      date,
      startTime: start,
      endTime: end,
      active: true
    };

    saveState(STORAGE_KEYS.RESERVATIONS, [...reservations, res], setReservations);
    return { 
      success: true, 
      message: `Auto-assigned Study Table #${availableTable.id} (${availableTable.location}) for ${date}!`,
      tableId: availableTable.id
    };
  };

  const reserveBookOnsite = (bookId: number, date: string, start: string, end: string) => {
    if (!currentUser) return { success: false, message: "Please log in first!" };

    const book = books.find(b => b.id === bookId);
    if (!book) return { success: false, message: "Book not found!" };
    if (book.copies <= 0) return { success: false, message: "No copies currently free to reserve!" };

    const nextId = reservations.length > 0 ? Math.max(...reservations.map(r => r.reservationid)) + 1 : 1;
    const res: BookReservation = {
      reservationid: nextId,
      userid: currentUser.id,
      bookid: bookId,
      tableid: 0,
      date,
      startTime: start,
      endTime: end,
      active: true
    };

    // Temporarily decrease book inventory copy counts for reservation period
    const updatedBooks = books.map(b => {
      if (b.id === bookId) return { ...b, copies: b.copies - 1 };
      return b;
    });

    saveState(STORAGE_KEYS.RESERVATIONS, [...reservations, res], setReservations);
    saveState(STORAGE_KEYS.BOOKS, updatedBooks, setBooks);
    return { success: true, message: `Onsite reservation of "${book.title}" registered successfully!` };
  };

  const cancelReservation = (resId: number) => {
    const target = reservations.find(r => r.reservationid === resId);
    if (!target) return;

    // Restore book counts if book reservation
    if (target.bookid > 0) {
      const updatedBooks = books.map(b => {
        if (b.id === target.bookid) return { ...b, copies: b.copies + 1 };
        return b;
      });
      saveState(STORAGE_KEYS.BOOKS, updatedBooks, setBooks);
    }

    const updatedRes = reservations.map(r => {
      if (r.reservationid === resId) return { ...r, active: false };
      return r;
    });

    saveState(STORAGE_KEYS.RESERVATIONS, updatedRes, setReservations);
  };

  // ADMIN OPERATIONS
  const addBook = (newBook: Omit<Book, "id" | "download_count" | "read_onsite_count" | "times_borrowed">) => {
    const nextId = books.length > 0 ? Math.max(...books.map(b => b.id)) + 1 : 1;
    const book: Book = {
      ...newBook,
      id: nextId,
      download_count: 0,
      read_onsite_count: 0,
      times_borrowed: 0
    };

    // Check title duplicate
    const titleExists = books.some(b => b.title.toLowerCase() === newBook.title.toLowerCase());
    if (titleExists) return { success: false, message: "A book with this title already exists!" };

    saveState(STORAGE_KEYS.BOOKS, [...books, book], setBooks);
    return { success: true, message: `Successfully added "${book.title}" to catalog!` };
  };

  const removeBook = (bookId: number) => {
    const target = books.find(b => b.id === bookId);
    if (!target) return { success: false, message: "Book selection invalid." };

    // Prevent deletions if book has outstanding borrowings
    const isBorrowed = transactions.some(t => t.bid === bookId && !t.returned);
    if (isBorrowed) {
      return { success: false, message: "Cannot exclude book! Copied inventories are still actively borrowed by library users." };
    }

    const filtered = books.filter(b => b.id !== bookId);
    saveState(STORAGE_KEYS.BOOKS, filtered, setBooks);
    return { success: true, message: `Successfully deleted references to "${target.title}".` };
  };

  const addTable = (location: string, capacity: number) => {
    if (tables.length >= 10) {
      return { success: false, message: "Table limits reached! Redora Study Rooms configure a maximum of 10 tables." };
    }

    const nextId = tables.length > 0 ? Math.max(...tables.map(t => t.id)) + 1 : 1;
    const newT: Table = { id: nextId, location, capacity };
    saveState(STORAGE_KEYS.TABLES, [...tables, newT], setTables);
    return { success: true, message: "Study table created successfully!" };
  };

  const removeTable = (tableId: number) => {
    const hasActiveRes = reservations.some(r => r.tableid === tableId && r.active);
    if (hasActiveRes) {
      return { success: false, message: "Cannot remove study tables with ongoing active reservations." };
    }

    const filtered = tables.filter(t => t.id !== tableId);
    saveState(STORAGE_KEYS.TABLES, filtered, setTables);
    return { success: true, message: "Table removed successfully." };
  };

  const deleteUser = (userId: number) => {
    const user = users.find(u => u.id === userId);
    if (!user) return { success: false, message: "User profile not found." };
    
    // Check borrowed books constraint
    if (user.borrowedIds && user.borrowedIds.length > 0) {
      return { success: false, message: `Cannot delete user! Reader has ${user.borrowedIds.length} borrowed books. Ask for returns first.` };
    }

    const updatedUsers = users.map(u => {
      if (u.id === userId) {
        return { ...u, isDeleted: true };
      }
      return u;
    });

    // Cancel dynamic active reservations owned by deleted user
    const updatedRes = reservations.map(r => {
      if (r.userid === userId && r.active) {
        return { ...r, active: false };
      }
      return r;
    });

    saveState(STORAGE_KEYS.USERS, updatedUsers, setUsers);
    saveState(STORAGE_KEYS.RESERVATIONS, updatedRes, setReservations);
    
    if (currentUser?.id === userId) {
      logout();
    }

    return { success: true, message: `Soft deletion complete for user file "${user.name}".` };
  };

  return (
    <LibraryContext.Provider value={{
      books, tables, users, transactions, fines, reservations, currentUser, adminLoggedIn,
      loginAsUser, loginAsAdmin, logout, registerUser,
      updateUserProfile, addFunds, activateMembership, cancelMembership,
      borrowBook, returnBook, readOnSite, downloadBook,
      reserveTableManual, reserveTableAuto, reserveBookOnsite, cancelReservation,
      addBook, removeBook, addTable, removeTable, deleteUser,
      getEffectiveBorrowLimit, hasOverdueBooks, getOverdueBooksCount,
      currentTheme, setTheme, clearDatabase, loadMockData
    }}>
      {children}
    </LibraryContext.Provider>
  );
};

export const useLibrary = () => {
  const context = useContext(LibraryContext);
  if (context === undefined) {
    throw new Error("useLibrary must be called within a LibraryProvider context");
  }
  return context;
};
