import { Book, Table, User } from "./types";

export const MOCK_BOOKS: Book[] = [
  {
    id: 1,
    title: "1984",
    author: "George Orwell",
    category: "Dystopian Fiction",
    isbn: "978-0451524935",
    publisher: "Secker & Warburg",
    year: 1949,
    copies: 7,
    download_count: 412,
    read_onsite_count: 195,
    times_borrowed: 215
  },
  {
    id: 2,
    title: "Clean Code",
    author: "Robert C. Martin",
    category: "Software Engineering",
    isbn: "978-0132350884",
    publisher: "Prentice Hall",
    year: 2008,
    copies: 4,
    download_count: 325,
    read_onsite_count: 242,
    times_borrowed: 148
  },
  {
    id: 3,
    title: "The Great Gatsby",
    author: "F. Scott Fitzgerald",
    category: "Fiction",
    isbn: "978-0743273565",
    publisher: "Scribner",
    year: 1925,
    copies: 6,
    download_count: 98,
    read_onsite_count: 82,
    times_borrowed: 122
  },
  {
    id: 4,
    title: "Introduction to Algorithms",
    author: "Thomas H. Cormen",
    category: "Computer Science",
    isbn: "978-0262046305",
    publisher: "MIT Press",
    year: 2022,
    copies: 5,
    download_count: 184,
    read_onsite_count: 121,
    times_borrowed: 76
  },
  {
    id: 5,
    title: "The Hobbit",
    author: "J.R.R. Tolkien",
    category: "Fantasy",
    isbn: "978-0261102217",
    publisher: "Allen & Unwin",
    year: 1937,
    copies: 8,
    download_count: 258,
    read_onsite_count: 159,
    times_borrowed: 194
  },
  {
    id: 6,
    title: "The Pragmatic Programmer",
    author: "David Thomas",
    category: "Software Engineering",
    isbn: "978-0135957059",
    publisher: "Addison-Wesley",
    year: 2019,
    copies: 3,
    download_count: 218,
    read_onsite_count: 137,
    times_borrowed: 91
  }
];

export const MOCK_TABLES: Table[] = [
  { id: 1, location: "Main Level Study Room A", capacity: 4 },
  { id: 2, location: "Main Level Study Room B", capacity: 4 },
  { id: 3, location: "Silent Zone Ground Suite A", capacity: 2 },
  { id: 4, location: "Silent Zone Ground Suite B", capacity: 1 },
  { id: 5, location: "Collaborative Study Lab 1", capacity: 8 },
  { id: 6, location: "Collaborative Study Lab 2", capacity: 6 }
];

export const MOCK_USERS: User[] = [
  {
    id: 1,
    name: "Alex Mercer",
    cnic: "42101-1234567-1",
    email: "alex.mercer@student.edu",
    username: "alex",
    password: "password",
    phone: "03001234567",
    type: "STUDENT",
    balance: 450.0,
    total_fines_paid: 20.0,
    isDeleted: false,
    borrowedIds: [],
    daily_borrows: 0,
    last_borrow_date: "",
    seatno: "CS-204",
    major: "Computer Science"
  },
  {
    id: 2,
    name: "Dr. Eleanor Vance",
    cnic: "42101-7654321-2",
    email: "eleanor.vance@faculty.edu",
    username: "eleanor",
    password: "password",
    phone: "03111222333",
    type: "FACULTY",
    balance: 1000.0,
    total_fines_paid: 0.0,
    isDeleted: false,
    borrowedIds: [],
    daily_borrows: 0,
    last_borrow_date: "",
    department: "Physics",
    designation: "Associate Professor",
    membership: {
      active: true,
      activationTime: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      expiryTime: new Date(Date.now() + 335 * 24 * 60 * 60 * 1000).toISOString(),
      durationDays: 365
    }
  },
  {
    id: 3,
    name: "Sarah Jenkins",
    cnic: "42101-1112223-3",
    email: "sarah@gmail.com",
    username: "sarah",
    password: "password",
    phone: "03334445555",
    type: "GUEST",
    balance: 150.0,
    total_fines_paid: 40.0,
    isDeleted: false,
    borrowedIds: [],
    daily_borrows: 0,
    last_borrow_date: "",
    purpose: "Reference materials for independent research project"
  }
];
