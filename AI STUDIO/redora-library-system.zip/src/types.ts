export type UserType = "STUDENT" | "FACULTY" | "GUEST";

export interface Membership {
  active: boolean;
  activationTime: string;
  expiryTime: string;
  durationDays: number;
}

export interface User {
  id: number;
  name: string;
  cnic: string;
  email: string;
  username: string;
  password: string;
  phone: string;
  type: UserType;
  balance: number;
  total_fines_paid: number;
  isDeleted: boolean;
  borrowedIds: number[];
  daily_borrows: number;
  last_borrow_date: string;
  membership?: Membership;
  // Student fields
  seatno?: string;
  major?: string;
  // Faculty fields
  department?: string;
  designation?: string;
  // Guest fields
  purpose?: string;
}

export interface Book {
  id: number;
  title: string;
  author: string;
  category: string;
  isbn: string;
  publisher: string;
  year: number;
  copies: number;
  download_count: number;
  read_onsite_count: number;
  times_borrowed: number;
}

export interface Transaction {
  tid: number;
  uid: number;
  bid: number;
  borrow_time: string; // ISO String
  due_time: string;    // ISO String
  return_time?: string; // ISO String
  return_date?: string; // Human Readable date
  returned: boolean;
}

export interface Fine {
  user_id: number;
  book_id: number;
  minuteslate: number;
  rate: number;
  originalAmount: number;
  finalAmount: number;
  discountApplied: boolean;
  paidAt?: string;
}

export interface Table {
  id: number;
  location: string;
  capacity: number;
}

export interface BookReservation {
  reservationid: number;
  userid: number;
  bookid: number;
  tableid: number; // 0 if it's a book reservation
  date: string;    // DD/MM/YYYY format
  startTime: string; // HH:MM 24-hr format
  endTime: string;   // HH:MM 24-hr format
  active: boolean;
}
